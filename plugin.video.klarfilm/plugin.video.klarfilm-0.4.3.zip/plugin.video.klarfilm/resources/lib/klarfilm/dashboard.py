"""GPL-3.0-or-later. Remote-friendly dashboard; home makes no network request."""
import sys
from urllib.parse import urlencode, parse_qs
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.klarfilm.runtime import state
from resources.lib.klarfilm.startup import inventory, episode_routes


def route(view, **params):
    return sys.argv[0] + '?' + urlencode(dict(params, function='klarfilm', view=view))


def add(label, path, folder=True, entry=None, description=''):
    item = xbmcgui.ListItem(label)
    from resources.lib.klarfilm.appearance import artwork
    item.setArt(artwork(xbmcaddon.Addon().getAddonInfo('path'), path))
    if description:
        item.getVideoInfoTag().setPlot(description)
    if entry:
        meta = entry['metadata']
        if meta.get('thumb'):
            item.setArt({'thumb': meta['thumb'], 'poster': meta['thumb']})
        tag = item.getVideoInfoTag()
        tag.setTitle(meta['title'])
        tag.setMediaType('episode' if meta.get('episode') else 'movie')
        tag.setPlaycount(int(entry['watched']))
        if entry['duration'] > 0 and not entry['watched']:
            tag.setResumePoint(entry['position'], entry['duration'])
        item.setProperty('IsPlayable', 'true')
        item.addContextMenuItems([('Aus Merkliste entfernen' if entry['watchlisted'] else 'Auf Merkliste setzen',
                                  'RunPlugin(' + route('toggle', media=entry['media']) + ')')])
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), path, item, folder)


def main(view='home'):
    from resources.lib.klarfilm.account_ui import VIEWS, manage
    if view in VIEWS:
        return manage(view)
    store = state()
    addon = xbmcaddon.Addon()
    args = {key: value[0] for key, value in parse_qs(sys.argv[2].lstrip('?')).items()}
    profile_name = store.remote_context.get('profile_name', 'Lokales Profil')
    xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Klarfilm · ' + profile_name)
    if view == 'toggle':
        added = store.toggle_watchlist(args.get('media', ''))
        xbmcgui.Dialog().notification('Klarfilm', 'Auf Merkliste gesetzt' if added else 'Aus Merkliste entfernt')
        xbmc.executebuiltin('Container.Refresh')
        return
    if view == 'home':
        items = [('Weiterschauen', 'continue', len(store.listing('continue', limit=None))),
                 ('Nächste bekannte Folge', 'next', len(store.next_episodes())),
                 ('Meine Merkliste', 'watchlist', len(store.listing('watchlist', limit=None))),
                 ('Neu und Entdecken', 'discover', None),
                 ('Meine Mediathek', 'library', None), ('Suche', 'search_menu', None),
                 ('Anbieter und Verbindungen', 'providers', None),
                 ('Konto, Profile und Einstellungen', 'account', None)]
        for label, key, count in items:
            add('[B]' + label + '[/B]' + (' · ' + str(count) if count is not None else ''), route(key))
    elif view in ('continue', 'next', 'watchlist', 'movies', 'episodes', 'history', 'discovered', 'search_local'):
        rows = store.next_episodes() if view == 'next' else store.listing(view, limit=None if view == 'search_local' else 200)
        if view == 'search_local':
            query = xbmcgui.Dialog().input('Titel in meiner Mediathek suchen').casefold().strip()
            rows = [row for row in rows if query and query in (row['metadata'].get('title', '') + ' ' + row['metadata'].get('showTitle', '')).casefold()][:200]
        for row in rows:
            meta = row['metadata']
            label = meta['title']
            if meta.get('episode'):
                label = (meta.get('showTitle') or label) + ' · S{}E{} · {}'.format(meta.get('season') or 0, meta['episode'], meta['title'])
            if row['duration'] > 0 and not row['watched']:
                label += ' · {} %'.format(int(100 * row['position'] / row['duration']))
            add(label, meta['route'], False, row)
        xbmcplugin.setContent(int(sys.argv[1]), 'videos')
        if not rows:
            xbmcgui.Dialog().notification('Klarfilm', 'Noch keine passenden Titel – Anbieter öffnen oder Suche nutzen')
    elif view == 'new_episodes':
        for label, params in episode_routes(addon.getAddonInfo('path'), addon.getSetting):
            add(label, sys.argv[0] + '?' + urlencode(params))
    elif view == 'discover':
        add('Neue Serienfolgen nach Anbieter', route('new_episodes'))
        add('Filme: Kino, neu für daheim und Streaming-Plattformen', sys.argv[0] + '?' + urlencode({'site': 'tmdb_browser', 'function': 'showMoviesMenu'}),
            description='Metadaten sind keine Zusage einer abspielbaren Quelle.')
        add('Serien entdecken – TMDb', sys.argv[0] + '?' + urlencode({'site': 'tmdb_browser', 'function': 'showTVShowsMenu'}))
        add('Zuletzt entdeckte Titel', route('discovered'))
        add('Alle Anbieter und Filmkataloge', route('upstream'))
    elif view == 'library':
        for label, key in [('Meine Filme', 'movies'), ('Meine Serienfolgen', 'episodes'), ('Zuletzt gesehen', 'history')]:
            add(label, route(key))
    elif view == 'search_menu':
        add('Anbieterübergreifend suchen', sys.argv[0] + '?' + urlencode({'site': 'globalSearch', 'function': 'globalSearch'}))
        add('In meiner Mediathek suchen', route('search_local'))
    elif view == 'providers':
        from resources.lib.klarfilm.runtime import request_root
        providers = inventory(addon.getAddonInfo('path'), addon.getSetting, request_root())
        for provider in sorted(providers, key=lambda p: ({'ready': 0, 'unknown': 1, 'issue': 2, 'disabled': 3}[p['state']], p['name'])):
            label = provider['name'] + ' · ' + provider['status']
            detail = provider['domain'] + '\n' + provider['auth'] + '\n' + provider['session'] + '\nLetztes gespeichertes Prüfergebnis; bestätigt noch keine Wiedergabe.'
            path = sys.argv[0] + '?' + urlencode({'site': provider['id'], 'function': 'load'}) if provider['enabled'] else route('settings')
            add(label, path, description=detail)
        add('Domains jetzt prüfen', sys.argv[0] + '?' + urlencode({'function': 'domainCheck'}))
        add('Synchronisierung und Konflikte', route('status'))
        add('VPN und Datenschutz', route('privacy'))
        add('Vollständige Anbieter-/Suchoberfläche', route('upstream'))
    elif view == 'status':
        counts = store.counts()
        message = addon.getSetting('klarfilm.sync_status') or 'Noch nicht verbunden'
        xbmcgui.Dialog().ok('Synchronisierung', message + '\nAusstehend: {} · Konflikte: {}\n'
            'Verlauf und Merkliste bleiben bei Ausfällen lokal gespeichert.'.format(
                counts.get('pending', 0) + counts.get('sending', 0), counts.get('conflict', 0)))
        if counts.get('conflict') and xbmcgui.Dialog().yesno('Fortschrittskonflikte',
                'Für die betroffenen Titel den Serverstand übernehmen? Lokale Konfliktstände werden verworfen.'):
            store.discard_conflicts()
    elif view == 'settings':
        addon.openSettings()
    elif view == 'privacy':
        xbmcgui.Dialog().ok('VPN und Datenschutz',
            'Kein Tunnelstatus bestätigt. Eigenen WireGuard-Ausgang und Netzwerksperre gemäß Anleitung einrichten.\n'
            'Das Add-on selbst verbirgt keine IP. Zugangsdaten werden nicht aus fremden Konten beschafft.')
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
    if view == 'home':
        addon.setSetting('klarfilm.service_enabled', 'true')
