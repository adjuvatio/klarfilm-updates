"""GPL-3.0-or-later. Local artwork selection; no network requests or skin changes."""
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import re

TILES = frozenset(('continue', 'next', 'watchlist', 'discover', 'library',
                   'search_menu', 'providers', 'account', 'movies', 'episodes', 'history'))
ALIASES = {'discovered':'discover', 'new_episodes':'episodes', 'search_local':'search_menu',
           'settings':'account', 'status':'providers', 'privacy':'providers',
           'upstream':'providers'}

def artwork(root, route):
    resources = Path(root) / 'resources'
    brand = resources / 'art' / 'brand'
    params = parse_qs(urlsplit(route).query)
    view = params.get('view', [''])[0]
    key = ALIASES.get(view, view)
    if key not in TILES:
        site = params.get('site', [''])[0]
        function = params.get('function', [''])[0]
        key = ('search_menu' if site == 'globalSearch' else
               'episodes' if function == 'showTVShowsMenu' else
               'movies' if function == 'showMoviesMenu' else 'library')
        if re.fullmatch(r'[a-z0-9_-]+', site):
            logo = resources / 'art' / 'sites' / (site + '.png')
            if logo.is_file():
                image = str(logo)
            else:
                image = str(brand / (key + '.png'))
        else:
            image = str(brand / (key + '.png'))
    else:
        image = str(brand / (key + '.png'))
    return {'icon':image, 'thumb':image, 'poster':image,
            'fanart':str(resources / 'fanart.jpg'),
            'clearlogo':str(resources / 'clearlogo.png')}
