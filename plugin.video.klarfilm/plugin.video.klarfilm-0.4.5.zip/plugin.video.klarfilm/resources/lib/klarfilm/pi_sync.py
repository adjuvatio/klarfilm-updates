"""GPL-3.0-or-later. Profile-scoped metadata synchronization with the private Pi."""
import json
import math
import re
import time
import ipaddress
import http.client
import ssl
from urllib.error import HTTPError
from urllib.parse import quote, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler, HTTPSHandler


def pi_server(value):
    from resources.lib.klarfilm.scope import secure_server
    url=secure_server(value)
    parsed=urlsplit(url)
    if parsed.scheme!='https' or not parsed.hostname.endswith('.ts.net') or parsed.port or parsed.path:
        raise ValueError('Die HTTPS-Server-Adresse aus der Pi-Verwaltung verwenden (…ts.net).')
    return url


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        return None


def local_address(value):
    if not value:return None
    addr=ipaddress.ip_address(value.strip())
    if addr.version!=4 or not addr.is_private or addr.is_loopback or addr.is_link_local:
        raise ValueError('Bitte die lokale IPv4-Adresse aus der Pi-Verwaltung verwenden.')
    return str(addr)


class LanConnection(http.client.HTTPSConnection):
    """Connect locally while retaining the trusted .ts.net TLS identity and SNI."""
    def __init__(self,*args,lan_host=None,**kw):
        super().__init__(*args,**kw)
        original=self._create_connection
        self._create_connection=lambda address,*a,**k:original((lan_host,8443),*a,**k)


class LanHTTPS(HTTPSHandler):
    def __init__(self,lan_host):
        super().__init__(context=ssl.create_default_context())
        self.lan_host=local_address(lan_host)
    def https_open(self,req):
        return self.do_open(lambda *a,**k:LanConnection(*a,lan_host=self.lan_host,**k),req,context=self._context)


def call(server,path,payload=None,token=None,method=None,lan_host=None):
    headers={'Content-Type':'application/json','X-Medienhub':'1'}
    if token: headers['Authorization']='Bearer '+token
    data=None if payload is None else json.dumps(payload,allow_nan=False).encode()
    req=Request(pi_server(server)+path,data=data,headers=headers,method=method)
    handlers=[NoRedirect()]
    if lan_host:handlers.append(LanHTTPS(lan_host))
    with build_opener(*handlers).open(req,timeout=5) as response:
        raw=response.read(4*1024*1024+1)
        if len(raw)>4*1024*1024: raise ValueError('Serverantwort zu groß')
        return json.loads(raw)


def pair(server,code,lan_host=None):
    return call(server,'/api/pair/claim',{'app':'klarfilm','code':code},lan_host=lan_host)


def context(server,reply,lan_host=None):
    return {'mode':'medienhub','server':pi_server(server),'account_id':'0'*31+'1',
            'profile_id':reply['profile'],'profile_name':reply['profile_name'],
            'device_id':reply['device_id'],'token':reply['token'],'lan_host':local_address(lan_host)}


def sync(store,active=None,should_stop=lambda:False):
    ctx=store.remote_context
    prefix='/api/v1/klarfilm/'+quote(ctx['profile_id'],safe='')
    for event in store.pending():
        if should_stop():return
        row={'_event_id':event['event_id'],'metadata':event['metadata'],
             'position':event['position'],'duration':event['duration'],
             'watchlisted':bool(event.get('watchlisted',False)),
             'watched':int(event['duration']>0 and event['position']/event['duration']>=.9),
             'updated':event.get('updated',1)}
        try:
            reply=call(ctx['server'],prefix+'/items/'+quote(event['metadata']['id'],safe=''),
                       {'expected_version':event['revision'],'data':row},ctx['token'],'PUT',**({'lan_host':ctx['lan_host']} if ctx.get('lan_host') else {}))
        except HTTPError as e:
            if e.code!=409:raise
            store.mark_conflict(event['metadata']['id'])
        else:
            store.acknowledge(event,reply['version'])
    with store.connect() as db:
        r=db.execute("SELECT value FROM config WHERE key='pi_cursor'").fetchone()
        cursor=int(r[0]) if r else 0
    while not should_stop():
        page=call(ctx['server'],prefix+'/changes?after='+str(cursor),token=ctx['token'],**({'lan_host':ctx['lan_host']} if ctx.get('lan_host') else {}))
        rows=page['changes']
        now_active=active() if callable(active) else active
        blocked=any(r['key']==now_active for r in rows)
        converted=[]
        for r in rows:
            if r['deleted']:
                # Do not delete local playback history silently. Future deletion UI can decide explicitly.
                continue
            value=dict(r['data'],revision=r['version'])
            if value.get('metadata',{}).get('id')!=r['key']:
                raise ValueError('Server-Medienkennung stimmt nicht überein')
            for k in ('position','duration','updated'):
                if not isinstance(value.get(k),(int,float)) or not math.isfinite(value[k]) or value[k]<0:
                    raise ValueError('Ungültiger Server-Fortschritt')
            if value['position']>value['duration']:
                raise ValueError('Ungültiger Server-Fortschritt')
            converted.append(value)
        store.accept_remote(converted,now_active)
        if blocked:return
        following=page['cursor']
        if rows and following<=cursor:raise ValueError('Ungültiger Server-Cursor')
        with store.connect() as db:
            db.execute("INSERT OR REPLACE INTO config VALUES('pi_cursor',?)",(str(following),))
        cursor=following
        if not page['has_more']:break


def import_local(source,target):
    import uuid
    total=0
    for row in source.listing('discovered',limit=None):
        if target.get(row['media']):continue
        target.observe(row['metadata'])
        event={'event_id':uuid.uuid4().hex,'metadata':row['metadata'],
               'position':row['position'],'duration':row['duration'],
               'watchlisted':bool(row['watchlisted']),'device':target.device(),'updated':row['updated'] or time.time()}
        with target.connect() as db:
            db.execute('UPDATE entries SET position=?,duration=?,watched=?,watchlisted=?,updated=? WHERE media=?',
                       (row['position'],row['duration'],row['watched'],row['watchlisted'],event['updated'],row['media']))
            db.execute('INSERT OR IGNORE INTO outbox(media,event) VALUES(?,?)',(row['media'],json.dumps(event)))
        total+=1
    return total
