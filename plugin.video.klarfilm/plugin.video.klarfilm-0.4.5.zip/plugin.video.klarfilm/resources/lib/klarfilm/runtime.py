"""GPL-3.0-or-later. Kodi integration; no website scraping in this module."""
import json
import os
import sys
import time
from urllib.parse import parse_qs, urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
import xbmcaddon
import xbmcgui
import xbmcvfs
from resources.lib.klarfilm.state import State, media_identity

_resume_choices = {}  # Per plugin invocation, shared by its source attempts only.


def current_context():
    from resources.lib.klarfilm.scope import validate_context
    raw = xbmcaddon.Addon().getSetting('klarfilm.session')
    return validate_context(json.loads(raw)) if raw else {}


def request_root():
    from resources.lib.klarfilm.scope import account_directory
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    context = current_context()
    folder = account_directory(profile, context) / 'shared' if context else __import__('pathlib').Path(profile)
    folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    return str(folder)


def state(context=None):
    from resources.lib.klarfilm.scope import state_path
    context = current_context() if context is None else context
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    path = state_path(profile, context)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    store = State(path)
    store.remote_context = dict(context)
    os.chmod(path, 0o600)
    return store


def params_meta(params, title='', route=''):
    def get(key):
        return params.get(key) or ''
    result = {'title': title or get('MovieTitle') or get('title'),
              'site': get('site'), 'showTitle': get('TVShowTitle'),
              'season': get('season'), 'episode': get('episode'),
              'year': get('year'), 'imdb_id': get('imdb_id'),
              'tmdb_id': get('tmdbID'), 'thumb': get('thumb') or get('trumb'),
              'route': route}
    result['kind'] = 'episode' if result['episode'] else 'movie'
    result['id'] = media_identity(result)
    return result


def observe(element, route):
    if element._mediaType not in ('movie', 'episode'):
        return
    params = {k: v[0] for k, v in parse_qs(urlsplit(route).query).items()}
    if params.get('isHoster') == 'true':
        return
    metadata = params_meta(params, element.getTitle(), route)
    state().observe(metadata)


def decorate(element, route, item):
    if element._mediaType not in ('movie', 'episode'):
        return
    params = {k: v[0] for k, v in parse_qs(urlsplit(route).query).items()}
    if params.get('isHoster') == 'true':
        return
    metadata = params_meta(params, element.getTitle(), route)
    prior = state().get(metadata['id'])
    if not prior:
        return
    action = sys.argv[0] + '?' + urlencode({'function': 'klarfilm', 'view': 'toggle', 'media': metadata['id']})
    item.addContextMenuItems([('Aus Merkliste entfernen' if prior['watchlisted'] else 'Auf Merkliste setzen', 'RunPlugin(' + action + ')')])
    tag = item.getVideoInfoTag()
    tag.setPlaycount(int(prior['watched']))
    tag.setResumePoint(prior['position'] if not prior['watched'] else 0, prior['duration'])


def prepare_playback(data, item):
    from resources.lib.handler.parameterHandler import ParameterHandler
    params = dict(ParameterHandler().getAllParameters())
    metadata = params_meta(params, data.get('title', ''), sys.argv[0] + '?' + urlencode(params))
    if not metadata['title']:
        return
    store = state()
    prior = store.get(metadata['id'])
    if prior:
        metadata['route'] = prior['metadata']['route']
        metadata['site'] = prior['metadata'].get('site', metadata['site'])
    store.observe(metadata)
    prior = store.get(metadata['id'])
    # A marked-gone title starts over; partial titles ask once before trying sources.
    from resources.lib.klarfilm.scope import context_key
    profile_key = context_key(store.remote_context)
    resume_key = profile_key + ':' + metadata['id']
    choice = _resume_choices.get(resume_key)
    if params.get('klarfilm_autonext') == '1':
        choice = str(prior['position']) if prior and not prior['watched'] else '0'
    if not choice and prior and prior['position'] > 5 and not prior['watched']:
        resume = xbmcgui.Dialog().yesno('Klarfilm', 'Bei {:02}:{:02} fortsetzen?'.format(
            int(prior['position']) // 60, int(prior['position']) % 60))
        choice = str(prior['position']) if resume else '0'
        _resume_choices[resume_key] = choice
    # Explicitly clear any URL-based resume from Kodi or another profile.
    item.setProperty('StartOffset', choice if choice and float(choice) > 0 else '0')
    item.getVideoInfoTag().setUniqueID(metadata['id'], 'klarfilm')
    item.getVideoInfoTag().setUniqueID(profile_key, 'klarfilm_profile')


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def api(path, payload=None, context=None, login_server=None):
    from resources.lib.klarfilm.scope import secure_server
    context = current_context() if context is None else dict(context)
    base = secure_server(login_server) if login_server else context.get('server', '')
    if not base:
        raise ValueError('Bei Klarfilm anmelden')
    headers = {'Content-Type': 'application/json'}
    if not login_server:
        headers.update({'Authorization': 'Bearer ' + context['token'], 'X-Klarfilm-Profile': context['profile_id']})
    request = Request(base + path, data=None if payload is None else json.dumps(payload).encode(), headers=headers)
    with build_opener(NoRedirect()).open(request, timeout=4) as response:
        return json.loads(response.read(4 * 1024 * 1024))


def shared_credential(provider):
    import re
    if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,59}', provider):
        raise ValueError('Ungültiger Anbieter')
    # Fetched on demand, not written as plaintext to local Kodi settings.
    return api('/vault/' + provider)


def sync_once(store, active=None, should_stop=lambda: False):
    from urllib.error import HTTPError
    context = dict(store.remote_context)
    if not context:
        return
    if context.get('mode') == 'medienhub':
        from resources.lib.klarfilm.pi_sync import sync
        return sync(store, active, should_stop)
    for event in store.pending()[:3]:
        if should_stop():
            return
        try:
            reply = api('/event', event, context=context)
        except HTTPError as e:
            if e.code != 409:
                raise
            store.mark_conflict(event['metadata']['id'])
        else:
            store.acknowledge(event, reply['revision'])
    after = ''
    while True:
        if should_stop():
            return
        page = api('/history/page?' + urlencode({'after': after, 'limit': 50}), context=context)
        store.accept_remote(page['items'], active() if callable(active) else active)
        following = page['next']
        if not following:
            break
        if following <= after:
            raise ValueError('Ungültiger Seitencursor')
        after = following

    # Only availability metadata is cached. Secret values stay in the server vault.
    from resources.lib.klarfilm.scope import account_directory
    from pathlib import Path
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    target = account_directory(profile, context) / 'vault-status.json'
    if should_stop():
        return
    entries = api('/vault/index', context=context)
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(entries), encoding='utf-8')
    os.chmod(temporary, 0o600)
    os.replace(temporary, target)
