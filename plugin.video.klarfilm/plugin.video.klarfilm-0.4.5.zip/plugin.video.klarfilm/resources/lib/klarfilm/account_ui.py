"""GPL-3.0-or-later. One household login, independent personal profiles, shared vault."""
import json
import sys
from urllib.error import HTTPError
from urllib.parse import urlencode, parse_qs
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from resources.lib.klarfilm.runtime import api, current_context, shared_credential
from resources.lib.klarfilm.scope import validate_context
from resources.lib.klarfilm.startup import inventory

VIEWS = {'account', 'login', 'logout', 'profiles', 'create_profile', 'rename_profile', 'vault', 'credential', 'devices', 'pi_connect'}


def pi_profiles():
    try:
        rows=json.loads(xbmcaddon.Addon().getSetting('klarfilm.pi.profiles') or '[]')
        return [validate_context(c) for c in rows if c.get('mode')=='medienhub']
    except (ValueError,TypeError,KeyError):
        return []


def remember_pi(value):
    from resources.lib.klarfilm.scope import context_key
    rows=[c for c in pi_profiles() if context_key(c)!=context_key(value)]
    rows.append(value)
    xbmcaddon.Addon().setSetting('klarfilm.pi.profiles',json.dumps(rows))


def connect_pi():
    from resources.lib.klarfilm.pi_sync import pair, context as pi_context, import_local
    from resources.lib.klarfilm.runtime import state, sync_once
    if not idle_required():return
    addon=xbmcaddon.Addon();dialog=xbmcgui.Dialog()
    server=dialog.input('Heimserver-Adresse aus der Mac-Verwaltung (https://…ts.net)',defaultt=addon.getSetting('klarfilm.pi.server'))
    if not server:return
    code=dialog.input('Klarfilm-Kopplungscode aus der Mac-Verwaltung')
    if not code:return
    lan=None
    if dialog.yesno('Verbindung im Heimnetz','Ist dieser Fire TV im selben Heimnetz wie dein Pi? Ja: Verbindung direkt über LAN, auch ohne Tailscale-App. Nein: Tailscale auf dem Fire TV muss aktiv sein.'):
        lan=dialog.input('Lokale Pi-Adresse aus der Mac-Verwaltung',defaultt='192.168.178.135')
        if not lan:return
    reply=pair(server,code,lan)
    value=validate_context(pi_context(server,reply,lan))
    original=state();target=state(value)
    # Preserve the paired token before any follow-up request or optional import.
    remember_pi(value);save_session(value);addon.setSetting('klarfilm.pi.server',value['server'])
    if original.path!=target.path and original.listing('discovered',limit=1) and dialog.yesno('Lokale Mediathek übernehmen?',
        'Die aktuelle lokale Mediathek in das Serverprofil „'+value['profile_name']+'“ kopieren? Der bisherige lokale Stand bleibt erhalten. Vorhandene Serverstände werden bei Konflikten nicht überschrieben.'):
        import_local(original,target)
    try:
        sync_once(target)
        addon.setSetting('klarfilm.sync_status','Verbunden – Konflikte prüfen' if target.counts().get('conflict') else 'Verbunden')
        dialog.notification('Heimserver verbunden',value['profile_name'])
    except Exception:
        addon.setSetting('klarfilm.sync_status','Gekoppelt – Abgleich wird im Hintergrund erneut versucht')
        dialog.ok('Gerät gekoppelt','Die Anmeldung ist gespeichert. Der Abgleich wird im Hintergrund erneut versucht. Tailscale muss auf diesem Gerät aktiv sein.')
    go_home()


def url(view, **params):
    return sys.argv[0] + '?' + urlencode(dict(params, function='klarfilm', view=view))


def save_session(context):
    context = validate_context(context)
    xbmcaddon.Addon().setSetting('klarfilm.session', json.dumps(context) if context else '')
    from resources.lib.cache import cCache
    cCache().clear()
    window = xbmcgui.Window(10000)
    keys = ['klarfilm.globalSearchText', 'klarfilm.globalSearchResults', 'klarfilm.alterSearchTitle', 'klarfilm.alterSearchResults', 'klarfilm.tmdb_browser.personQuery']
    from pathlib import Path
    for site in (Path(xbmcaddon.Addon().getAddonInfo('path')) / 'sites').glob('*.py'):
        keys += ['klarfilm.' + site.stem + '.lastSearchText', 'klarfilm.' + site.stem + '.lastYear']
    for key in keys:
        window.clearProperty(key)


def go_home():
    xbmc.executebuiltin('Container.Update(' + url('home') + ',replace)')


def idle_required():
    if xbmc.Player().isPlaying():
        xbmcgui.Dialog().ok('Profil wechseln', 'Bitte zuerst die laufende Wiedergabe beenden.')
        return False
    return True


def add(label, view, **params):
    item = xbmcgui.ListItem(label)
    from resources.lib.klarfilm.appearance import artwork
    item.setArt(artwork(xbmcaddon.Addon().getAddonInfo('path'), url('account')))
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), url(view, **params), item, True)


def hidden(prompt):
    return xbmcgui.Dialog().input(prompt, type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)


def manage(view):
    addon = xbmcaddon.Addon()
    dialog = xbmcgui.Dialog()
    context = current_context()
    args = {key: value[0] for key, value in parse_qs(sys.argv[2].lstrip('?')).items()}
    try:
        if view == 'pi_connect':
            connect_pi()
            return
        elif view == 'account':
            if context.get('mode') == 'medienhub':
                add('Heimserver-Profil: '+context.get('profile_name','Mein Profil')+' – wechseln','profiles')
                add('Anderes Heimserver-Profil verbinden','pi_connect')
                add('Heimserver auf diesem Gerät abmelden','logout')
                add('Kodi-Add-on-Einstellungen','settings')
                xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=False)
                return
            if context:
                add('Profil: ' + context.get('profile_name', 'Standard') + ' – wechseln', 'profiles')
                add('Weiteres persönliches Profil anlegen', 'create_profile')
                add('Aktuelles Profil umbenennen', 'rename_profile')
                add('Gemeinsame Anbieterzugänge', 'vault')
                add('Angemeldete Geräte verwalten', 'devices')
                add('Von diesem Haushalt abmelden', 'logout')
            else:
                add('Mit meinem Pi-Heimserver verbinden (Kopplungscode)','pi_connect')
                add('Bei meinem Klarfilm-Haushaltskonto anmelden', 'login')
                dialog.notification('Klarfilm', 'Ohne Anmeldung wird das getrennte lokale Profil verwendet')
            add('Kodi-Add-on-Einstellungen', 'settings')
        elif view == 'login':
            if not idle_required(): return
            server = addon.getSetting('klarfilm.server')
            if not server:
                server = dialog.input('Klarfilm-Server: HTTPS oder http://10.77.0.1:8792')
            username = dialog.input('Klarfilm-Benutzername', defaultt=addon.getSetting('klarfilm.username'))
            if not username: return
            password = hidden('Klarfilm-Passwort')
            if not password: return
            reply = api('/auth/login', {'username': username, 'password': password,
                                      'device': xbmc.getInfoLabel('System.FriendlyName') or 'Kodi'}, login_server=server)
            profiles = reply.pop('profiles')
            selected = 0 if len(profiles) == 1 else dialog.select('Wer schaut?', [p['name'] for p in profiles])
            initial = dict(reply, server=server, profile_id=profiles[0]['id'])
            if selected < 0:
                api('/auth/logout', {}, context=initial)
                return
            profile = profiles[selected]
            save_session(dict(reply, server=server, profile_id=profile['id'], profile_name=profile['name'], profiles=profiles))
            addon.setSetting('klarfilm.server', server)
            addon.setSetting('klarfilm.username', username)
            go_home()
            return
        elif view == 'logout':
            if not idle_required(): return
            if context.get('mode') == 'medienhub':
                from resources.lib.klarfilm.pi_sync import call
                from resources.lib.klarfilm.scope import context_key
                from urllib.parse import quote
                revoked=True
                try:
                    call(context['server'],'/api/v1/klarfilm/'+quote(context['profile_id'],safe='')+'/session',{},context['token'],'DELETE',lan_host=context.get('lan_host'))
                except Exception:
                    revoked=False
                rows=[c for c in pi_profiles() if context_key(c)!=context_key(context)]
                addon.setSetting('klarfilm.pi.profiles',json.dumps(rows));save_session({})
                if not revoked:dialog.ok('Lokal abgemeldet','Pi nicht erreichbar. Den Gerätezugang bitte zusätzlich in der Mac-Verwaltung widerrufen.')
                go_home()
                return
            revoked = True
            try:
                api('/auth/logout', {}, context=context)
            except Exception:
                revoked = False
            save_session({})
            if not revoked:
                dialog.ok('Lokal abgemeldet', 'Server nicht erreichbar. Dieses Gerät später über ein anderes angemeldetes Gerät auch zentral abmelden.')
            go_home()
            return
        elif not context:
            dialog.ok('Klarfilm', 'Bitte zuerst beim Haushaltskonto anmelden.')
        elif view == 'profiles':
            if not idle_required(): return
            if context.get('mode') == 'medienhub':
                choices=pi_profiles()
                choice=dialog.select('Wer schaut?',[c.get('profile_name','Profil') for c in choices]+['Anderes Profil per Code verbinden'])
                if choice==len(choices):connect_pi()
                elif choice>=0:save_session(choices[choice]);go_home()
                return
            try:
                profiles = api('/profiles')
            except Exception:
                profiles = context.get('profiles', [])
                dialog.notification('Klarfilm', 'Offline: zuletzt bekannte Profile')
            selected = dialog.select('Wer schaut?', [p['name'] for p in profiles])
            if selected >= 0:
                profile = profiles[selected]
                save_session(dict(context, profile_id=profile['id'], profile_name=profile['name'], profiles=profiles))
                go_home()
            return
        elif view == 'create_profile':
            if not idle_required(): return
            title = dialog.input('Name des neuen Profils')
            if title:
                profile = api('/profiles', {'name': title})
                profiles = api('/profiles')
                save_session(dict(context, profile_id=profile['id'], profile_name=profile['name'], profiles=profiles))
                go_home()
            return
        elif view == 'rename_profile':
            title = dialog.input('Neuer Profilname', defaultt=context.get('profile_name', ''))
            if title:
                api('/profiles/rename', {'id': context['profile_id'], 'name': title})
                save_session(dict(context, profile_name=title, profiles=api('/profiles')))
                go_home()
            return
        elif view == 'vault':
            saved = {row['provider']: row for row in api('/vault/index')}
            for provider in inventory(addon.getAddonInfo('path'), addon.getSetting):
                label = provider['name'] + (' – Zugang zentral gespeichert' if provider['id'] in saved else ' – Zugang hinterlegen')
                add(label, 'credential', provider=provider['id'])
        elif view == 'credential':
            provider = args['provider']
            value = shared_credential(provider)
            username = dialog.input('Anbieter-Benutzername', defaultt=value['username'])
            if not username: return
            password = hidden('Anbieter-Passwort – leer behält das vorhandene Passwort')
            if not password: password = value['password']
            if not password:
                dialog.ok('Zugang speichern', 'Ein Passwort fehlt.')
                return
            api('/vault/' + provider, dict(value, username=username, password=password))
            dialog.ok('Zugang zentral gespeichert',
                'Für alle Profile und angemeldeten Geräte dieses Haushalts verfügbar.\n'
                'Der aktuelle Adapter hat noch keinen automatischen Konto-Login.')
            go_home()
            return
        elif view == 'devices':
            devices = api('/devices')
            labels = [d['label'] + (' (dieses Gerät)' if d['id'] == context['device_id'] else '') for d in devices]
            selected = dialog.select('Gerät zur Abmeldung auswählen', labels)
            if selected >= 0 and dialog.yesno('Gerät abmelden', labels[selected] + ' jetzt abmelden?'):
                api('/devices/revoke', {'id': devices[selected]['id']})
                if devices[selected]['id'] == context['device_id']: save_session({})
                go_home()
            return
    except HTTPError as error:
        message = {401: 'Anmeldung ungültig oder abgelaufen. Bitte erneut anmelden.', 403: 'Dieses Profil gehört nicht zu deinem Haushalt.', 409: 'Zugang wurde zwischenzeitlich geändert. Bitte erneut öffnen.', 429: 'Zu viele Anmeldeversuche. Bitte nach einer Minute erneut versuchen.'}.get(error.code, 'Serveranfrage fehlgeschlagen.')
        dialog.ok('Klarfilm', message)
        return
    except ValueError as error:
        dialog.ok('Klarfilm', str(error))
        return
    except Exception:
        dialog.ok('Klarfilm', 'Anfrage fehlgeschlagen. Server-Adresse, Anmeldung und Verbindung prüfen. Bei einem Speicherkonflikt den Zugang neu öffnen.')
        return
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
