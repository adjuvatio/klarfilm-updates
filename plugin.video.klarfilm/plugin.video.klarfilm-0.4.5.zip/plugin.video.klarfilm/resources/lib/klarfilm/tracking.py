"""GPL-3.0-or-later. Started only after the first successful UI opening."""

def run():
    import threading
    import time
    from urllib.error import HTTPError
    import xbmc
    import xbmcaddon
    from resources.lib.klarfilm.runtime import state, sync_once, current_context
    from resources.lib.klarfilm.scope import context_key

    try:
        from resources.lib.klarfilm.launcher import refresh_launcher_art
        refresh_launcher_art(xbmcaddon.Addon(), xbmc.executeJSONRPC)
    except Exception:
        xbmc.log('Klarfilm: Startsymbol konnte noch nicht erneuert werden', xbmc.LOGWARNING)
    monitor = xbmc.Monitor()
    from resources.lib.klarfilm.autonext import Completion, make_player, next_episode, playback_route
    completion = Completion()
    player = make_player(xbmc, completion)
    stores = {}
    lock = threading.Lock()
    active = None
    active_store = None
    sample = None
    saved = 0
    synced = 0
    worker = None
    from resources.lib.klarfilm.domain_service import DomainService
    domains = DomainService(xbmcaddon.Addon())


    def obtain(context):
        key = context_key(context)
        with lock:
            if key not in stores:
                stores[key] = state(context)
            else:
                stores[key].remote_context = dict(context)
            return stores[key]


    def persist():
        if active_store and active and sample:
            active_store.sample(active, sample[0], sample[1])


    def sync_background(context):
        addon = xbmcaddon.Addon()
        try:
            # Include profiles known from this login, so their pending local changes
            # continue to synchronize after the person switches to another profile.
            for profile in context.get('profiles', []):
                obtain(dict(context, profile_id=profile['id'], profile_name=profile['name']))
            with lock:
                snapshots = list(stores.values())
            conflicts = 0
            for store in snapshots:
                if monitor.abortRequested():
                    return
                target = dict(store.remote_context)
                if target.get('server') != context['server'] or target.get('account_id') != context['account_id']:
                    continue
                if context.get('mode') == 'medienhub' and target.get('profile_id') != context['profile_id']:
                    continue
                # Use this household's current device token while retaining its profile.
                store.remote_context = target if context.get('mode') == 'medienhub' else dict(target, token=context['token'], device_id=context['device_id'])
                sync_once(store, lambda: active if store is active_store else None, should_stop=monitor.abortRequested)
                conflicts += store.counts().get('conflict', 0)
            if context_key(current_context()) == context_key(context):
                addon.setSetting('klarfilm.sync_status', 'Verbunden – Konflikte prüfen' if conflicts else 'Verbunden')
        except HTTPError as error:
            if context_key(current_context()) == context_key(context):
                addon.setSetting('klarfilm.sync_status', 'Erneut anmelden – Gerät abgemeldet oder Sitzung abgelaufen' if error.code == 401 else 'Serveranfrage fehlgeschlagen')
        except Exception:
            if context_key(current_context()) == context_key(context):
                addon.setSetting('klarfilm.sync_status', 'Offline – Daten bleiben im jeweiligen Profil')


    while not monitor.abortRequested():
        try:
            domains.tick()
            context = current_context()
            selected = obtain(context)
            finished = completion.take()
            if finished:
                media, scope_key = finished
                if (scope_key == context_key(context)
                        and xbmcaddon.Addon().getSetting('klarfilm.autonext') != 'false'
                        and not player.isPlaying()
                        and not monitor.abortRequested()):
                    following = next_episode(selected, media)
                    if following:
                        # Complete the old sample before another playback can replace it.
                        if active == media:
                            persist()
                            active, active_store, sample = None, None, None
                        player.play(playback_route(following))
            playing = player.isPlayingVideo()
            tag = player.getVideoInfoTag() if playing else None
            identity = tag.getUniqueID('klarfilm') if tag else ''
            scope = tag.getUniqueID('klarfilm_profile') if tag else ''
            if active and (not playing or identity != active or scope != context_key(active_store.remote_context)):
                persist()
                active, active_store, sample = None, None, None
            if identity and not active and scope == context_key(context) and selected.get(identity):
                active, active_store, sample, saved = identity, selected, None, 0
            if active:
                position, duration = player.getTime(), player.getTotalTime()
                if duration > 0 and 0 <= position <= duration:
                    sample = (position, duration)
                    if time.monotonic() - saved >= 10:
                        persist()
                        saved = time.monotonic()
            if context and time.monotonic() - synced >= 15 and (worker is None or not worker.is_alive()):
                synced = time.monotonic()
                worker = threading.Thread(target=sync_background, args=(dict(context),), daemon=False)
                worker.start()
        except Exception:
            xbmc.log('Klarfilm: Profilverlauf derzeit nicht erfassbar', xbmc.LOGWARNING)
        if monitor.waitForAbort(1):
            break
    try:
        persist()
    except Exception:
        pass

    # No Python worker may outlive its Kodi interpreter. Each request has a timeout.
    if worker is not None:
        worker.join()

    domains.close()
