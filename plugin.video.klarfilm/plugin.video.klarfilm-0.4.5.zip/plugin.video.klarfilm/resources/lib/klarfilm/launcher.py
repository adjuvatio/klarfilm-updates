"""GPL-3.0-or-later. Refresh only this add-on's cached launch artwork via Kodi."""
import json
from urllib.parse import unquote

REVISION = '0.4.5'
FILES = frozenset(('icon.png', 'logo.png', 'clearlogo.png', 'resources/icon.png',
                   'resources/logo.png', 'resources/clearlogo.png', 'resources/art/icon.png',
                   'resources/art/xstream.png', 'resources/art/xstream_settings.png',
                   'resources/art/brand/v2/icon.png'))
ORIGIN = 'https://klarfilm-kodi-downloads.versatileflamingo8.chatgpt.site'


def owns_launcher(url, root):
    if not isinstance(url, str):
        return False
    for _ in range(3):
        decoded = unquote(url)
        if decoded == url:
            break
        url = decoded
    if url.startswith('image://'):
        url = url[8:].rstrip('/')
    url = url.replace('\\', '/')
    prefixes = (str(root).replace('\\', '/').rstrip('/') + '/',
                'special://home/addons/plugin.video.klarfilm/',
                ORIGIN + '/repo/plugin.video.klarfilm/')
    return any(url.startswith(prefix) and url[len(prefix):] in FILES for prefix in prefixes)


def refresh_launcher_art(addon, execute):
    if addon.getSetting('klarfilm.launcher_art_revision') == REVISION:
        return
    def rpc(method, params):
        reply = json.loads(execute(json.dumps({'jsonrpc':'2.0', 'id':1,
                                              'method':method, 'params':params})))
        if 'error' in reply or 'result' not in reply:
            raise RuntimeError('Kodi texture request failed')
        return reply['result']
    response = rpc('Textures.GetTextures', {'properties':['url'],
                   'filter':{'field':'url', 'operator':'contains', 'value':'plugin.video.klarfilm'}})
    root = addon.getAddonInfo('path')
    for texture in response.get('textures', []):
        if owns_launcher(texture.get('url'), root):
            if rpc('Textures.RemoveTexture', {'textureid':texture['textureid']}) != 'OK':
                raise RuntimeError('Kodi texture refresh failed')
    addon.setSetting('klarfilm.launcher_art_revision', REVISION)
