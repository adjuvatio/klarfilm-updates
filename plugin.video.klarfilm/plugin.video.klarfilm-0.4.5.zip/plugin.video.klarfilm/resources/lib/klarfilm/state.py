"""GPL-3.0-or-later. Local catalogue, durable offline outbox and media identity."""
import hashlib
import json
import math
import re
import sqlite3
import time
import uuid
from urllib.parse import urlsplit


def media_identity(meta):
    kind = 'episode' if meta.get('episode') not in (None, '', False) else 'movie'
    external = str(meta.get('imdb_id') or '').strip()
    if re.fullmatch(r'tt\d+', external):
        base = 'imdb:' + external
    elif str(meta.get('tmdb_id') or '').isdigit():
        base = 'tmdb:' + ('tv:' if kind == 'episode' else 'movie:') + str(meta['tmdb_id'])
    else:
        # No speculative title-based merge across providers: remakes and aliases collide.
        title = str((meta.get('showTitle') or meta.get('title') or '') if kind == 'episode' else meta.get('title') or '')
        text = json.dumps([meta.get('site', ''), title.casefold().strip(), str(meta.get('year') or '')])
        base = 'local:' + hashlib.sha256(text.encode()).hexdigest()[:32]
    if kind == 'episode':
        base += ':s{}:e{}'.format(meta.get('season') or 0, meta['episode'])
    return kind + ':' + base


def valid_record(meta):
    if not isinstance(meta, dict) or not isinstance(meta.get('title'), str) or not meta['title'].strip():
        raise ValueError('Titel fehlt')
    if len(json.dumps(meta)) > 32768:
        raise ValueError('Eintrag zu groß')
    path = urlsplit(str(meta.get('route', '')))
    if path.scheme != 'plugin' or path.netloc != 'plugin.video.klarfilm':
        raise ValueError('Nur interne Wiedergaberouten erlaubt')
    if meta.get('id') != media_identity(meta):
        raise ValueError('Medien-ID passt nicht')
    return meta


class State:
    def __init__(self, path):
        self.path = str(path)
        with self.connect() as db:
            db.executescript('''
              CREATE TABLE IF NOT EXISTS entries (
                media TEXT PRIMARY KEY, metadata TEXT NOT NULL, position REAL DEFAULT 0,
                duration REAL DEFAULT 0, watched INTEGER DEFAULT 0,
                revision INTEGER DEFAULT 0, updated REAL DEFAULT 0, discovered REAL NOT NULL);
              CREATE TABLE IF NOT EXISTS outbox (
                media TEXT PRIMARY KEY, event TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending');
              CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            ''')
            db.execute('INSERT OR IGNORE INTO config VALUES (?,?)', ('device', uuid.uuid4().hex))
            if 'watchlisted' not in {r[1] for r in db.execute('PRAGMA table_info(entries)')}:
                db.execute('ALTER TABLE entries ADD COLUMN watchlisted INTEGER NOT NULL DEFAULT 0')

    def connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        return db

    def device(self):
        with self.connect() as db:
            return db.execute("SELECT value FROM config WHERE key='device'").fetchone()[0]

    def observe(self, meta):
        valid_record(meta)
        with self.connect() as db:
            db.execute('INSERT INTO entries(media,metadata,discovered) VALUES (?,?,?) '
                       'ON CONFLICT(media) DO UPDATE SET metadata=excluded.metadata',
                       (meta['id'], json.dumps(meta), time.time()))

    def get(self, media):
        with self.connect() as db:
            row = db.execute('SELECT * FROM entries WHERE media=?', (media,)).fetchone()
            if not row:
                return None
            result = dict(row)
            result['metadata'] = json.loads(result['metadata'])
            return result

    def listing(self, mode='continue', limit=200):
        with self.connect() as db:
            order = 'discovered DESC' if mode == 'discovered' else 'updated DESC, discovered DESC'
            rows = db.execute('SELECT * FROM entries ORDER BY ' + order).fetchall()
        result = []
        for row in rows:
            entry = dict(row)
            entry['metadata'] = json.loads(entry['metadata'])
            if mode == 'continue' and (entry['watched'] or entry['position'] <= 0):
                continue
            if mode == 'history' and (entry['updated'] <= 0 or entry['duration'] <= 0):
                continue
            if mode == 'watchlist' and not entry['watchlisted']:
                continue
            if mode in ('movies', 'episodes') and entry['metadata'].get('kind', 'movie') != ('movie' if mode == 'movies' else 'episode'):
                continue
            result.append(entry)
        return result if limit is None else result[:limit]

    def toggle_watchlist(self, media):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM entries WHERE media=?', (media,)).fetchone()
            if not row:
                raise ValueError('Unbekannter Titel')
            value = not bool(row['watchlisted'])
            db.execute('UPDATE entries SET watchlisted=? WHERE media=?', (int(value), media))
            event = {'event_id': uuid.uuid4().hex, 'metadata': json.loads(row['metadata']),
                     'position': row['position'], 'duration': row['duration'],
                     'watchlisted': value, 'device': self.device()}
            event['updated'] = time.time()
            db.execute("INSERT INTO outbox(media,event) VALUES (?,?) ON CONFLICT(media) DO UPDATE SET event=excluded.event WHERE outbox.status='pending'",
                       (media, json.dumps(event)))
            return value

    def next_episodes(self):
        groups = {}
        # Only episodes that are actually in the local/received catalogue.
        for entry in self.listing('episodes', limit=None):
            meta = entry['metadata']
            try:
                order = (int(meta.get('season') or 0), float(meta['episode']))
            except (KeyError, ValueError, TypeError):
                continue
            series = entry['media'].rsplit(':s', 1)[0]
            groups.setdefault(series, []).append((order, entry))
        selected = []
        for episodes in groups.values():
            episodes.sort(key=lambda pair: pair[0])
            watched = [order for order, row in episodes if row['watched']]
            last = max(watched) if watched else (-1, -1)
            pending = [row for order, row in episodes if not row['watched'] and order > last]
            if pending:
                selected.append(pending[0])
        return selected

    def sample(self, media, position, duration):
        if not all(math.isfinite(x) for x in (position, duration)) or not 0 <= position <= duration or duration <= 0:
            raise ValueError('Ungültiger Fortschritt')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT metadata,watchlisted FROM entries WHERE media=?', (media,)).fetchone()
            if not row:
                raise ValueError('Unbekannter Titel')
            event = {'event_id': uuid.uuid4().hex, 'metadata': json.loads(row['metadata']),
                     'position': position, 'duration': duration, 'watchlisted': bool(row['watchlisted']), 'device': self.device()}
            now = time.time()
            event['updated'] = now
            db.execute('UPDATE entries SET position=?,duration=?,watched=?,updated=? WHERE media=?',
                       (position, duration, int(position / duration >= .9), now, media))
            # Once a request may have reached the server, retain its exact event
            # for idempotent retry. New samples remain in entries until its ack.
            db.execute("INSERT INTO outbox(media,event) VALUES (?,?) ON CONFLICT(media) DO UPDATE SET event=excluded.event WHERE outbox.status='pending'",
                       (media, json.dumps(event)))

    def pending(self):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            result = []
            for row in db.execute("SELECT outbox.*,entries.revision FROM outbox JOIN entries ON entries.media=outbox.media WHERE status IN ('pending','sending') LIMIT 3"):
                event = json.loads(row['event'])
                event['revision'] = row['revision']
                result.append(event)
                db.execute("UPDATE outbox SET status='sending' WHERE media=?", (row['media'],))
            return result

    def acknowledge(self, event, revision):
        media = event['metadata']['id']
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('UPDATE entries SET revision=MAX(revision,?) WHERE media=?', (revision, media))
            row = db.execute('SELECT event FROM outbox WHERE media=?', (media,)).fetchone()
            if row and json.loads(row[0])['event_id'] == event['event_id']:
                db.execute('DELETE FROM outbox WHERE media=?', (media,))
                latest = db.execute('SELECT * FROM entries WHERE media=?', (media,)).fetchone()
                if (latest['position'], latest['duration'], bool(latest['watchlisted'])) != (event['position'], event['duration'], bool(event.get('watchlisted', False))):
                    next_event = dict(event, event_id=uuid.uuid4().hex, position=latest['position'], duration=latest['duration'], watchlisted=bool(latest['watchlisted']))
                    next_event.pop('revision', None)
                    next_event['metadata'] = json.loads(latest['metadata'])
                    next_event['updated'] = latest['updated'] or time.time()
                    db.execute('INSERT INTO outbox(media,event) VALUES (?,?)', (media, json.dumps(next_event)))

    def mark_conflict(self, media):
        with self.connect() as db:
            db.execute("UPDATE outbox SET status='conflict' WHERE media=?", (media,))

    def counts(self):
        with self.connect() as db:
            return {r[0]: r[1] for r in db.execute('SELECT status,COUNT(*) FROM outbox GROUP BY status')}

    def accept_remote(self, remote, active=None):
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            for row in remote:
                meta = valid_record(row['metadata'])
                media = meta['id']
                if media == active or db.execute('SELECT 1 FROM outbox WHERE media=?', (media,)).fetchone():
                    continue
                old = db.execute('SELECT revision,discovered FROM entries WHERE media=?', (media,)).fetchone()
                if old and old[0] >= row['revision']:
                    continue
                db.execute('INSERT OR REPLACE INTO entries VALUES (?,?,?,?,?,?,?,?,?)',
                    (media, json.dumps(meta), row['position'], row['duration'], row['watched'],
                     row['revision'], row['updated'], old['discovered'] if old else time.time(), int(bool(row.get('watchlisted', False)))))

    def discard_conflicts(self):
        # Explicit user action: keep remote progress; never silently rewind it.
        with self.connect() as db:
            db.execute("UPDATE entries SET revision=-1 WHERE media IN (SELECT media FROM outbox WHERE status='conflict')")
            db.execute("DELETE FROM outbox WHERE status='conflict'")
            db.execute("DELETE FROM config WHERE key='pi_cursor'")
