"""GPL-3.0-or-later. Own Kodi panel; does not depend on the active skin's folder view."""
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import sys
from resources.lib.klarfilm.appearance import artwork

def show_navigation(entries, addon, profile, view='home'):
    import xbmcgui
    root = addon.getAddonInfo('path')
    brand = Path(root) / 'resources/art/brand/v2'
    titles = {'home':'Dein Kino. Deine Serien.', 'library':'Meine Mediathek',
              'discover':'Entdecken', 'search_menu':'Suche',
              'providers':'Anbieter & Verbindungen', 'new_episodes':'Neue Serienfolgen'}
    class Navigation(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.selected = None
            self.entries = list(entries)
            self.stack = []
            self.current_view = view
            self.raw_items = None
        def onInit(self):
            self.setProperty('klarfilm.background', str(brand / 'backdrop.png'))
            self.setProperty('klarfilm.logo', str(brand / 'clearlogo.png'))
            self.setProperty('klarfilm.title', titles.get(self.current_view, self.current_view.replace('_', ' ').title()))
            self.setProperty('klarfilm.subtitle', profile + ' · ' + addon.getAddonInfo('version'))
            items = []
            for i, (label, path, *rest) in enumerate(self.entries):
                item = self.raw_items[i] if self.raw_items is not None else xbmcgui.ListItem(label)
                if self.raw_items is None:
                    item.setArt(artwork(root, path))
                items.append(item)
            panel = self.getControl(9000)
            panel.reset()
            panel.addItems(items)
            self.setFocusId(9000)
        def onClick(self, control):
            if control == 9000:
                position = self.getControl(9000).getSelectedPosition()
                if 0 <= position < len(self.entries):
                    target = self.entries[position][1]
                    params = {k: v[0] for k,v in parse_qs(urlsplit(target).query).items()}
                    # Repository updates are Kodi-native actions, not folders.
                    # Leave the modal and launch the add-on browser explicitly.
                    if params.get('function') == 'klarfilm' and params.get('view') == 'check_updates':
                        self.selected = '__klarfilm_check_updates__'
                        self.close()
                        return
                    internal = params.get('function') == 'klarfilm' and params.get('view') in (
                        'home', 'library', 'series', 'series_seasons', 'series_episodes',
                        'movies', 'history', 'continue_movies', 'next', 'watchlist', 'search_history',
                        'discover', 'search_menu', 'providers', 'new_episodes', 'discovered', 'repeat_search', 'search_local')
                    if internal:
                        from resources.lib.klarfilm.dashboard import main
                        new_view = params.pop('view')
                        params.pop('function', None)
                        next_entries = main(new_view, embedded=True, embedded_args=params)
                        self.stack.append((self.current_view, self.entries, self.raw_items))
                        self.raw_items = None
                        self.current_view = new_view
                        self.entries = next_entries
                        self.onInit()
                    else:
                        # Render provider directories in the same persistent Klarfilm window.
                        # Playback and actions remain delegated to Kodi's native dispatcher.
                        if (params.get('site') or params.get('view') == 'upstream') and len(self.entries[position]) > 2 and self.entries[position][2]:
                            try:
                                import xbmcplugin
                                import xstream
                                old_argv = sys.argv[:]
                                original_add = xbmcplugin.addDirectoryItem
                                original_end = xbmcplugin.endOfDirectory
                                captured = []
                                def collect(handle, url, item, folder, *a, **kw):
                                    captured.append((url, item, folder))
                                    return True
                                xbmcplugin.addDirectoryItem = collect
                                xbmcplugin.endOfDirectory = lambda *a, **kw: True
                                try:
                                    sys.argv = [urlsplit(target).scheme + '://' + urlsplit(target).netloc + urlsplit(target).path, old_argv[1], '?' + urlsplit(target).query]
                                    xstream.parseUrl()
                                finally:
                                    sys.argv = old_argv
                                    xbmcplugin.addDirectoryItem = original_add
                                    xbmcplugin.endOfDirectory = original_end
                                self.stack.append((self.current_view, self.entries, self.raw_items))
                                self.entries = [(item.getLabel(), url, folder, None, '') for url, item, folder in captured]
                                self.raw_items = [item for url, item, folder in captured]
                                self.current_view = 'Anbieter'
                                self.onInit()
                            except Exception:
                                import xbmc
                                xbmc.log('Klarfilm: Anbieteransicht konnte nicht eingebettet werden', xbmc.LOGERROR)
                                xbmcgui.Dialog().notification('Klarfilm', 'Anbieter konnte nicht geöffnet werden')
                        elif len(self.entries[position]) > 2 and not self.entries[position][2]:
                            import xbmc
                            xbmc.executebuiltin('RunPlugin(' + target + ')')
                        else:
                            import xbmc
                            xbmcgui.Dialog().notification('Klarfilm', 'Diese Aktion benötigt eine eigene Klarfilm-Ansicht')
        def onAction(self, action):
            if action.getId() == 13:
                self.close()
            elif action.getId() in (9, 10, 92, 216, 247, 257):
                if self.stack:
                    self.current_view, self.entries, self.raw_items = self.stack.pop()
                    self.onInit()
                else:
                    # Back from root returns to Klarfilm home instead of exposing
                    # Kodi's underlying directory. Explicit exit via stop button.
                    if self.current_view != 'home':
                        from resources.lib.klarfilm.dashboard import main
                        self.entries = main('home', embedded=True, embedded_args={})
                        self.current_view = 'home'
                        self.raw_items = None
                        self.onInit()
                    else:
                        self.onInit()
    window = Navigation('KlarfilmHome.xml', root, 'Default', '1080i')
    window.doModal()
    selected = window.selected
    del window
    if selected == '__klarfilm_check_updates__':
        import xbmc
        xbmc.executebuiltin('UpdateAddonRepos')
        if xbmcgui.Dialog().yesno('Klarfilm aktualisieren',
                'Klarfilm-Update jetzt über das installierte Repository anfordern? '
                'Kodi prüft Version und Berechtigungen.'):
            xbmc.executebuiltin('InstallAddon(plugin.video.klarfilm)')
            xbmcgui.Dialog().notification('Klarfilm',
                'Update angefordert – Installation durch Kodi prüfen')
        return None
    return selected
