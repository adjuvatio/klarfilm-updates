"""GPL-3.0-or-later. Single, deferred Kodi service entry point."""

def main():
    import xbmc
    import xbmcaddon
    monitor = xbmc.Monitor()
    # Installation enables a service immediately. Do not load the player,
    # database, resolver, providers or network code during this transaction.
    if monitor.waitForAbort(10):
        return
    addon = xbmcaddon.Addon('plugin.video.klarfilm')
    while addon.getSetting('klarfilm.service_enabled') != 'true':
        if monitor.waitForAbort(2):
            return
    if monitor.abortRequested():
        return
    try:
        from resources.lib.klarfilm.tracking import run
        run()
    except Exception:
        import traceback
        xbmc.log('Klarfilm service stopped: ' + traceback.format_exc(), xbmc.LOGERROR)


if __name__ == '__main__':
    main()
