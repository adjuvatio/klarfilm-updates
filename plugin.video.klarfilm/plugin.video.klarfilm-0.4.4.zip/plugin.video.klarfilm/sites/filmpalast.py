# -*- coding: utf-8 -*-
# Python 3

# Always pay attention to the translations in the menu!
# Keine Sprachlogik (seit dem 10.09.2026): die Seite ist deutsch, englische Fassungen
# fuehrt sie als Genre „Englisch" — das steht in unserer dynamischen Genre-Liste
# (Filme > Genre) und traegt die (EN)-Kennung ueber die Adresse.

import re
import time
import concurrent.futures
import xbmcgui
from resources.lib.handler.parameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler, REQUEST_ERRORS
from resources.lib.logger import logger
from resources.lib.tools import cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui


SITE_IDENTIFIER = 'filmpalast'
SITE_NAME = 'FilmPalast'
SITE_ICON = 'filmpalast.png'

if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'filmpalast.to')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_MAIN = 'https://' + DOMAIN
URL_MOVIES = URL_MAIN + '/movies/%s'
URL_SEARCH = URL_MAIN + '/search/title/%s'
URL_SERIES = URL_MAIN + '/serien/view'


def load():
    logger.info('Load %s' % SITE_NAME)
    xbmcgui.Window(10000).clearProperty('klarfilm.filmpalast.lastSearchText')
    params = ParameterHandler()
    params.setParam('sUrl', URL_MAIN)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)  # Neu auf der Seite
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showMoviesMenu'))   # Filme (Submenü)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showSeriesMenu'))   # Serien (Submenü)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search
    cGui().setEndOfDirectory()


def showMoviesMenu(): # Submenü Filme: Alle Filme / Top Filme / IMDB-Bewertung / Genre / A-Z
    params = ParameterHandler()
    params.setParam('sUrl', URL_MOVIES % 'new')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30542), SITE_IDENTIFIER, 'showEntries'), params)    # All Movies / Alle Filme
    params.setParam('sUrl', URL_MOVIES % 'top')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30509), SITE_IDENTIFIER, 'showEntries'), params)    # Top movies
    params.setParam('sUrl', URL_MOVIES % 'imdb')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30510), SITE_IDENTIFIER, 'showEntries'), params)    # IMDB rating
    params.setParam('sUrl', URL_MOVIES % 'new')
    params.setParam('value', 'genre')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showValue'), params)      # Genre
    params.setParam('value', 'movietitle')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30814), SITE_IDENTIFIER, 'showValue'), params)      # A-Z
    cGui().setEndOfDirectory()


def showSeriesMenu(): # Submenü Serien: Alle / A-Z
    params = ParameterHandler()
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30518), SITE_IDENTIFIER, 'showEntries'), params)    # All Series
    params.setParam('value', 'movietitle')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30814), SITE_IDENTIFIER, 'showValue'), params)      # A-Z
    cGui().setEndOfDirectory()


def _requestUrl(sUrl):
    # Kodiert unmittelbar vor dem Abruf (movie2k-Muster). Die Seite schreibt
    # Genre-Links roh mit Umlaut ins Markup ('/search/genre/Komödie') — ohne
    # Kodierung bricht urllib mit UnicodeEncodeError ab. Kodiert wird NIE im
    # Parameter (der Parameterweg dekodiert per unquote_plus wieder), sondern nur
    # hier. '%' bleibt in der safe-Liste, damit bereits kodierte Adressen (die
    # Suchadresse aus _searchUrl) nicht ein zweites Mal kodiert werden;
    # Leerzeichen werden zu %20.
    return cParser.urlEncode(sUrl, safe=':/?&=%#+')


def showValue():
    params = ParameterHandler()
    value = params.getValue("value")
    oRequest = cRequestHandler(_requestUrl(params.getValue('sUrl')))
    sHtmlContent = oRequest.request()
    pattern = '<section[^>]id="%s">(.*?)</section>' % value
    isMatch, sContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sContainer, 'href="([^"]+)">([^<]+)')
        aResult = sorted(aResult, key=lambda x: x[1].lower())
        for sUrl, sName in aResult:
            params.setParam('sUrl', sUrl)
            cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    if not isMatch:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def _parsePage(sHtmlContent):
    """Parst eine einzelne Seite und gibt (isMatch, aResult) zurück."""
    pattern = r'<article[^>]*>\s*<a href="([^"]+)" title="([^"]+)">\s*<img src=["\']([^"\']+)["\'][^>]*>(.*?)</article>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        pattern = r'<a[^>]*href="([^"]*)"[^>]*title="([^"]*)"[^>]*>[^<]*<img[^>]*src=["\']([^"\']*)["\'][^>]*>\s*</a>(\s*)</article>'
        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    return isMatch, aResult if isMatch else []


def _getNextPageUrl(sHtmlContent):
    """Extrahiert die nächste Seiten-URL oder gibt False zurück.

    Das Muster haengt am VORWAERTS-Link selbst: zwischen `>` und dem `+` darf kein
    weiteres Tag stehen. Vorher konnte die Suche stattdessen den Link auf Seite 1
    erwischen, weil auf der letzten Trefferseite ein Leerzeichen vor dem `>` steht
    (`href='…/1' >1</a>`) — daraus wurde eine kaputte Adresse mit Anfuehrungszeichen
    und Leerzeichen, die die Seite mit 404 beantwortet hat.
    """
    pattern = r'<a class="pageing[^"]*"\s*href=[\'"]?([^\'">]+)[\'"]?\s*>[^<]*\+\s*</a>'
    isMatch, sNextUrl = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        sNextUrl = sNextUrl.replace("'", "").replace('"', '').strip()
        if sNextUrl.startswith('/'):
            sNextUrl = URL_MAIN + sNextUrl
        return sNextUrl
    return False


def _searchUrl(sSearchText, iPage=1):
    """Adresse einer Suchseite. Seite 1 ist die Suchadresse, die Folgeseiten
    haengen die Seitenzahl als Pfadstueck an — die Form des Vorwaerts-Links der
    Seite (`/search/title/<begriff>/2`, Mitschnitt 21.10.2026). Ob es eine
    Folgeseite gibt, entscheidet allein dieser Link (_getNextPageUrl): auf der
    letzten Seite fehlt er, und jenseits des Endes wiederholt die Seite nur den
    Inhalt der letzten Seite (gemessen an 5 von 5 Begriffen).

    quote statt quotePlus, damit Leerzeichen als %20 uebergeben werden. Gebaut
    wird IMMER aus dem rohen Suchbegriff, nie aus dem Link selbst: der
    Weiter-Eintrag traegt nur Begriff und Seitenzahl, weil eine kodierte Adresse
    den Parameterweg nicht uebersteht (unquote_plus, Regel in den Projektregeln)
    — ein `#` im Begriff wuerde die Adresse sonst abschneiden.
    """
    sUrl = URL_SEARCH % cParser.quote(sSearchText)
    if iPage > 1:
        sUrl += '/%d' % iPage
    return sUrl


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not sSearchText:
        # Weiter-Seite der Suche: Kodi ruft die Funktion neu auf, Begriff und
        # Seitenzahl stehen dann nur noch im Parameter. Ohne den Begriff liefe die
        # Folgeseite ungefiltert.
        sSearchText = params.getValue('sSearchText') or False
    iPage = 1
    nextUrl = False
    if sSearchText:
        iPage = int(params.getValue('page') or 1)
    elif not entryUrl:
        entryUrl = params.getValue('sUrl')
    isTvshow = False

    while True:
        if sSearchText:
            entryUrl = _searchUrl(sSearchText, iPage)
        # Eine Folgeseite der Suche meldet Fehler nicht als Fenster: dort gilt wie
        # beim Blaettern „Kein Eintrag gefunden" (Seite 1 meldet wie bisher).
        oRequest = cRequestHandler(_requestUrl(entryUrl), ignoreErrors=(sGui is not False or iPage > 1))
        sHtmlContent = oRequest.request()
        isMatch, aResult = _parsePage(sHtmlContent)
        if not isMatch:
            break
        nextUrl = _getNextPageUrl(sHtmlContent)
        if not sSearchText:
            break
        # Titelfilter wie an allen Filterstellen (cParser.searchTitle, mit
        # Umlaut-Umschrift); der eigene Vergleich bis 14.10.2026 (Sonderzeichen raus,
        # Teilstring) lieferte bei koenig/könig/star wars dieselben Treffer
        aResult = [row for row in aResult if cParser.searchTitle(sSearchText, row[1])]
        if aResult or sGui or not nextUrl:
            break
        # Seite nach dem Titelfilter leer, aber der Vorwaerts-Link fuehrt weiter:
        # gleich weiterblaettern statt dem Nutzer leere Seiten zu zeigen (Jack
        # 21.10.2026 an hdfilme „der pate"). Nur in der Einzelsuche — die globale
        # Suche bleibt bei Seite 1.
        iPage += 1
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    iShown = 0
    seen_tv_shows = set()

    # KEINE Sortierung — auch nicht in der Suche: jede Liste kommt seitenweise und
    # behaelt die Reihenfolge der Seite (neueste zuerst). Je Seite A-Z zu sortieren
    # saehe wie eine vollstaendige Liste aus und zerstoerte nur diese Information
    # (Regel: Sortieren und Blaettern schliessen sich aus).
    for sUrl, sName, sThumbnail, sDummy in aResult:
        isTvshow, _ = cParser.parse(sName, r'S\d\dE\d\d')

        # Dedupe fuer Serien: je Serie nur der erste Folgen-Eintrag. Verglichen wird
        # ohne Gross-/Kleinschreibung — die Seite schreibt dieselbe Serie in beiden
        # Formen ("Fear the Walking Dead" und "Fear The Walking Dead", 21.10.2026),
        # angezeigt wird der Name des ersten Eintrags.
        if isTvshow:
            cleanNameMatch = re.search(r'(.*?)\s*S\d+E\d+', sName, re.IGNORECASE)
            if cleanNameMatch:
                cleanName = cleanNameMatch.group(1).strip()
                if cleanName.lower() in seen_tv_shows:
                    continue
                seen_tv_shows.add(cleanName.lower())
                sName = cleanName

        if sThumbnail.startswith('/'):
            sThumbnail = URL_MAIN + sThumbnail

        isYear, sYear = cParser.parseSingleResult(sDummy, r'Jahr:[^>]([\d]+)')
        isDuration, sDuration = cParser.parseSingleResult(sDummy, r'(?:Laufzeit|Spielzeit):[^>]([\d]+)')
        isRating, sRating = cParser.parseSingleResult(sDummy, 'Imdb:[^>]([^/]+)')

        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        if isYear: oGuiElement.setYear(sYear)
        if isDuration: oGuiElement.addItemValue('duration', sDuration)
        if isRating: oGuiElement.addItemValue('rating', sRating.replace(',', '.'))

        if sUrl.startswith('//'):
            params.setParam('entryUrl', 'https:' + sUrl)
        else:
            params.setParam('entryUrl', sUrl)
        
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        if isYear: params.setParam('sYear', sYear)  # Aki: Year an showSeasons weitergeben
        oGui.addFolder(oGuiElement, params, isTvshow, total)
        iShown += 1

    if sGui:
        return
    # Weiter-Eintrag mit FRISCHEM ParameterHandler: der oben in der Schleife benutzte
    # traegt noch entryUrl, sName und sThumbnail des LETZTEN Listeneintrags mit sich.
    # Die Folgeseite braucht davon nichts, und geerbte Werte sind eine Falle, sobald
    # showEntries irgendwann mehr als sUrl liest.
    if sSearchText:
        # Suche: eine Seite je Aufruf, die Folgeseite ueber den Weiter-Eintrag mit
        # Begriff und Seitenzahl (Bauform wie bei den anderen Seiten); ohne Gesamtzahl,
        # die Seite nennt keine. Leere Seiten wurden oben uebersprungen; ohne Treffer
        # und ohne Folgeseite kommt die Meldung „Kein Eintrag gefunden" (belegt mit
        # "koenig", Audit 01.09.2026).
        if not iShown:
            oGui.showInfo()
        if nextUrl:
            nextParams = ParameterHandler()
            nextParams.setParam('sSearchText', sSearchText)
            nextParams.setParam('page', iPage + 1)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', nextParams)
    elif nextUrl:
        nextParams = ParameterHandler()
        nextParams.setParam('sUrl', nextUrl)
        oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', nextParams)
    oGui.setView('tvshows' if isTvshow else 'movies')
    oGui.setEndOfDirectory()

def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue("sThumbnail")
    sName = params.getValue('sName')
    sTmdbID = params.getValue('tmdbID') or ''
    sYear = params.getValue('sYear') or ''  # Aki: Year aus Listen-Ebene uebernehmen
    oRequest = cRequestHandler(_requestUrl(sUrl))
    sHtmlContent = oRequest.request()
    pattern = r'<a[^>]*class="staffTab"[^>]*data-sid="(\d+)"[^>]*>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        cGui().showInfo()
        return
    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '"description">([^<]+)')
    # Die Reiter stehen im Markup NICHT immer in der richtigen Reihenfolge (Breaking Bad
    # liefert 3, 2, 4, 1, 5). Deshalb nach Nummer sortieren und Doppelte entfernen —
    # bei den uebrigen Serien aendert das nichts, dort steht die Liste schon aufsteigend.
    aResult = sorted({str(int(s)) for s in aResult if str(s).isdigit()}, key=int) or aResult
    total = len(aResult)
    for sSeason in aResult:
        oGuiElement = cGuiElement(cConfig().getLocalizedString(30512) + ' ' + str(sSeason), SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setTVShowTitle(sName)
        oGuiElement.setSeason(sSeason)
        oGuiElement.setMediaType('season')
        if sTmdbID:
            oGuiElement.addItemValue('tmdb_id', sTmdbID)
        if sYear:
            oGuiElement.addItemValue('year', sYear)  # Aki: Year auf Staffel setzen
        oGuiElement.setThumbnail(sThumbnail)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue("sThumbnail")
    sSeason = params.getValue('season')
    sShowName = params.getValue('TVShowTitle')
    oRequest = cRequestHandler(_requestUrl(sUrl))
    sHtmlContent = oRequest.request()

    # Die Staffelreiter der Seite (data-sid) taugen NICHT als Zuordnung: gemessen an
    # 110 Serien liegen bei zweien mehrere Staffeln in einem Container (Outlander:
    # S1-S3 im Container 3) oder ein Reiter hat gar keinen eigenen (Fear The Walking
    # Dead: Reiter 1 und 2). Beides fuehrte zu leeren oder vermischten Folgenlisten.
    # Verlaesslich ist die Staffelnummer in der Adresse selbst — danach wird gruppiert.
    aResult = _episodeLinks(sHtmlContent, sUrl, sSeason)
    if not aResult:
        # Fallback fuer Serien, deren Folgen nicht dem s01e01-Schema folgen:
        # der alte Weg ueber den Container mit passender data-sid.
        pattern = r'<div[^>]*class="staffelWrapperLoop[^"]*"[^>]*data-sid="%s">(.*?)</ul></div>' % sSeason
        isMatch, sContainer = cParser.parseSingleResult(sHtmlContent, pattern)
        if isMatch:
            isMatch, aLinks = cParser.parse(sContainer, 'href="([^"]+)')
            if isMatch:
                aResult = [(l, cParser.parseSingleResult(l, r'e(\d+)')[1]) for l in aLinks]
    if not aResult:
        cGui().showInfo()
        return

    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '"description">([^<]+)')
    total = len(aResult)
    for sUrl, sName in aResult:
        # Eine Form auf allen Sites ("S01E01", cParser.episodeLabel); die Adresse fuehrt die Folge
        # zweistellig (s01e01) — nur das Label, setEpisode bekommt den Wert unveraendert
        oGuiElement = cGuiElement(cParser.episodeLabel(sSeason, sName), SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setTVShowTitle(sShowName)
        oGuiElement.setSeason(sSeason)
        oGuiElement.setEpisode(sName)
        oGuiElement.setMediaType('episode')
        if sUrl.startswith('//'):
            params.setParam('entryUrl', 'https:' + sUrl)
        else:
            params.setParam('entryUrl', sUrl)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def _episodeLinks(sHtmlContent, sSeriesUrl, sSeason):
    """Folgen-Adressen EINER Staffel, aus der ganzen Detailseite gesammelt.

    Die Seite verlinkt jede Folge als <serien-slug>-sXXeYY. Gesucht wird deshalb
    nach genau diesem Schema mit dem Slug der aufgerufenen Serie — so koennen
    weder Folgen einer fremden Serie noch Folgen einer anderen Staffel hineinlaufen.
    Sortiert wird nach Folgennummer, doppelte Adressen fliegen raus.
    """
    sSlug = re.sub(r'-s\d+e\d+.*$', '', sSeriesUrl.split('/stream/')[-1].split('?')[0])
    if not sSlug:
        return []
    try:
        iSeason = int(sSeason)
    except (TypeError, ValueError):
        return []
    # Der Bindestrich vor der Staffelkennung ist OPTIONAL: dieselbe Serie fuehrt beide
    # Schreibweisen (outlander-s03e10 neben outlanders03e01). Entdeckt wird die Folge
    # ausserdem in mehreren Adressformen (// und https://) — deshalb wird ueber die
    # FOLGENNUMMER entdoppelt, sonst steht die Folge der aufgerufenen Seite zweimal
    # in der Liste.
    pattern = r'href="((?://|https?://)[^"]*?/stream/%s-?s0*%de(\d+))"' % (re.escape(sSlug), iSeason)
    aFound = []
    seen = set()
    for sLink, sEp in re.findall(pattern, sHtmlContent):
        try:
            iEp = int(sEp)
        except ValueError:
            continue
        if iEp in seen:
            continue
        seen.add(iEp)
        aFound.append((sLink, sEp))
    aFound.sort(key=lambda x: int(x[1]))
    return aFound


def showHosters():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    if '-english' in sUrl: sLang = '(EN)'
    else: sLang = ''
    sHtmlContent = cRequestHandler(_requestUrl(sUrl), caching=False).request()
    pattern = 'hostName">([^<]+).*?(http[^"]+)'
    releaseQuality = r'class="rb">.*?(\d\d\d+)p\.'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    isQuality, sQuality = cParser.parseSingleResult(sHtmlContent, releaseQuality)
    if not isQuality: sQuality = '720'
    hosters = []
    if isMatch:
        for sName, sUrl in aResult:
            sName = sName.split(' HD')[0].strip()
            if 'Filemoon' in sName or 'Swiftload' in sName or 'Vidhide' in sName:
                # Referer = einbettende Hauptdomain, aus URL_MAIN statt hartkodiert:
                # wechselt die Domain, bliebe ein Literal auf der alten stehen.
                sUrl = sUrl + '$$' + URL_MAIN + '/'
                if cConfig().isBlockedHoster(sName)[0]: continue  # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
                hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I]%s [%sp][/I]' % (sName, sLang, sQuality), 'languageCode': sLang, 'quality': sQuality}
                hosters.append(hoster)
            else:
                if cConfig().isBlockedHoster(sName)[0]: continue # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
                hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I]%s [%sp][/I]' % (sName, sLang, sQuality), 'languageCode': sLang, 'quality': sQuality}
                hosters.append(hoster)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters

def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    win = xbmcgui.Window(10000)
    sSearchText = win.getProperty('klarfilm.filmpalast.lastSearchText')
    if not sSearchText:
        sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
        if not sSearchText: return
        win.setProperty('klarfilm.filmpalast.lastSearchText', sSearchText)
    # Das Verzeichnis schliesst showEntries selbst ab — so wie bei jeder
    # Weiter-Seite der Suche, die Kodi direkt dort aufruft.
    _search(False, sSearchText)


def _search(oGui, sSearchText):
    showEntries(False, oGui, sSearchText)
