# -*- coding: utf-8 -*-
# Python 3

# Always pay attention to the translations in the menu!

import concurrent.futures
import re
import time
import xbmcgui
from resources.lib.handler.parameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler, REQUEST_ERRORS
from resources.lib.logger import logger
from resources.lib.wrappers.meinecloud import resolveMeinecloud, resolveMeinecloudSerial, expandHosterList, buildHosterFromUrl, buildMergedHosters, MEINECLOUD_TRIGGER, isPlatformUrl, platformImdbId, platformSnippetId, packSourceUrls, unpackSourceUrls
from resources.lib.tools import cParser, cUtil
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'streamcloud'
SITE_NAME = 'Streamcloud'
SITE_ICON = 'streamcloud.png'

if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'streamcloud.date')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_MAIN = 'https://' + DOMAIN + '/'
URL_MAINPAGE = URL_MAIN + 'streamcloud/'
URL_MOVIES = URL_MAIN + 'filme-stream/'
URL_KINO = URL_MAIN + 'kinofilme/'
# „Beliebt“ (/beliebte-filme/) ist BEWUSST kein Menuepunkt: die Seite liefert dort
# 200 Eintraege auf einer Seite, und die Film/Serie-Erkennung braucht je Eintrag einen
# Abruf — die Liste lud zu lange (ausgebaut am 24.09.2026). Nicht wieder einbauen.
URL_FAVOURITE_MOVIE_PAGE = URL_MAIN + 'beliebte-filme/'
URL_SERIES = URL_MAIN + 'serien/'
URL_SEARCH = URL_MAIN + 'index.php?story=%s&do=search&subaction=search'


def load():
    logger.info('Load %s' % SITE_NAME)
    xbmcgui.Window(10000).clearProperty('klarfilm.streamcloud.lastSearchText')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30881), SITE_IDENTIFIER, 'showRows'))  # Startseite
    params = ParameterHandler()
    params.setParam('sUrl', URL_KINO)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showEntries'), params)  # Latest Releases
    params.setParam('sUrl', URL_MOVIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showEntries'), params)  # Movies
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showSeries'), params)  # Series
    params.setParam('sUrl', URL_MAINPAGE)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showGenre'), params)    # Categories
    params.setParam('sUrl', URL_MAINPAGE)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search
    cGui().setEndOfDirectory()


# Startseite der Seite (seit ihrem Umbau am 05.10.2026): jede Reihe steckt in einer eigenen
# <section class="sc-r …"> mit <h2 class="sc-r-t">Name</h2> und Karten
# <a class="sc-c sc-c-v|sc-c-w" href=… title=…> (Bild, Titel, Meta-Zeile „2026 · ★ 7.3" oder nur
# das Jahr). Ueber die Section begrenzt, damit die letzte Reihe nicht bis zum Dokumentende laeuft.
_RE_ROW = re.compile(r'<section class="sc-r[^"]*">(.*?)</section>', re.S)
_RE_ROW_HEAD = re.compile(r'<h2 class="sc-r-t">(.*?)</h2>', re.S)
_RE_ROW_CARD = re.compile(r'<a class="sc-c([^"]*)" href="([^"]+)" title="([^"]*)"[^>]*>(.*?)</a>', re.S)
_RE_CARD_IMG = re.compile(r'<img[^>]+src="([^"]+)"')
_RE_CARD_META = re.compile(r'class="sc-cw?-m">([^<]*)<')


def _homeRows(sHtmlContent):
    """Reihen der Startseite in Seitenreihenfolge als [(Name, Karten)]. Name und Einteilung
    kommen aus dem Markup — aendert die Seite ihre Reihen, aendert sich das Menue mit.
    Reihen ohne Namen oder ohne Karten fallen weg (kein toter Menuepunkt)."""
    aRows = []
    for sSection in _RE_ROW.findall(sHtmlContent or ''):
        mHead = _RE_ROW_HEAD.search(sSection)
        aCards = _RE_ROW_CARD.findall(sSection)
        if not mHead or not aCards:
            continue
        sLabel = cUtil.unescape(cUtil.removeHtmlTags(mHead.group(1))).strip()
        if sLabel:
            aRows.append((sLabel, aCards))
    return aRows


def _absoluteUrl(sUrl):
    if sUrl.startswith('//'):
        return 'https:' + sUrl
    return sUrl if sUrl.startswith('http') else URL_MAIN.rstrip('/') + '/' + sUrl.lstrip('/')


def showRows():
    """Startseite: je Reihe der Seite ein Ordner (Trends heute, Neu: Filme, Neu: Serien,
    Beliebte …, Top bewertet, Genre-Reihen — was die Seite gerade fuehrt)."""
    aRows = _homeRows(cRequestHandler(URL_MAINPAGE).request())
    if not aRows:
        cGui().showInfo()
        return
    for sLabel, aCards in aRows:
        params = ParameterHandler()
        params.setParam('sRow', sLabel)
        oGuiElement = cGuiElement(sLabel, SITE_IDENTIFIER, 'showRowEntries')
        mImg = _RE_CARD_IMG.search(aCards[0][3])
        if mImg:
            oGuiElement.setThumbnail(_absoluteUrl(mImg.group(1)))
        cGui().addFolder(oGuiElement, params)
    cGui().setEndOfDirectory()


def showRowEntries():
    """Die Titel EINER Reihe der Startseite, so viele wie die Seite zeigt (keine Alle-Links:
    Filme, Serien und Genre stehen ohnehin im Menue). Die Startseite kommt aus dem Cache."""
    params = ParameterHandler()
    sRow = params.getValue('sRow')
    aCards = []
    for sLabel, aRowCards in _homeRows(cRequestHandler(URL_MAINPAGE).request()):
        if sLabel == sRow:
            aCards = aRowCards
            break
    if not aCards:
        cGui().showInfo()
        return
    params.setParam('sRow', '')
    aUrls = [_absoluteUrl(cUtil.unescape(sUrl)) for _c, sUrl, _t, _i in aCards]
    # Film oder Serie steht nicht auf der Karte — wie in showEntries ueber die Detailseite,
    # vorher parallel geholt (Hilfsabruf, still), die Pruefung unten trifft den Cache
    _prefetchDetails(aUrls)
    total = len(aCards)
    for (sClass, _sUrl, sTitle, sInner), sUrl in zip(aCards, aUrls):
        # Seitendefekt NUR der Startseite: Apostrophe stehen dort als \&#039; (mit Backslash)
        # in Titel, alt-Text und Kartentext; die Listenseiten sind sauber (gemessen 05.10.2026;
        # am 14.10.2026 gemischt, 3 Karten mit und 12 ohne Backslash — beide Formen landen hier)
        sName = cUtil.unescape(sTitle).replace("\\'", "'").strip()
        if not sName:
            continue  # namenlose Karte: kein Eintrag ohne Titel (wie bei animetoast entschieden)
        detailHtml = cRequestHandler(sUrl, ignoreErrors=True).request()
        isSeriesMatch, _ = cParser.parseSingleResult(detailHtml, r'data-num="\d+x\d+"')
        isTvshow = bool(isSeriesMatch or _hasMeinecloudSerial(detailHtml))
        mImg = _RE_CARD_IMG.search(sInner)
        sThumb = _absoluteUrl(mImg.group(1)) if mImg else ''
        if 'sc-c-w' in sClass:
            # Querformat-Karte (Trends heute, Serien im Trend): Szenenbild statt Poster — das Poster der
            # ohnehin geladenen Detailseite nehmen, kein Extra-Abruf
            sThumb = _detailCover(detailHtml) or sThumb
        mMeta = _RE_CARD_META.search(sInner)
        sMeta = mMeta.group(1) if mMeta else ''
        mYear = re.search(r'\b(\d{4})\b', sMeta)
        sYear = mYear.group(1) if mYear else ''
        mRating = re.search(r'★\s*([\d.]+)', sMeta)
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setThumbnail(sThumb)
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        if sYear:
            oGuiElement.setYear(sYear)
        if mRating:
            oGuiElement.addItemValue('rating', mRating.group(1))
        params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumb)
        params.setParam('sYear', sYear)
        cGui().addFolder(oGuiElement, params, isTvshow, total)
    cGui().setView('movies')
    cGui().setEndOfDirectory()


def showGenre(entryUrl=False):
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl)
    sHtmlContent = oRequest.request()    
    # Die Genres stehen im Filter-Panel der Startseite (<details class="sc-f"> mit
    # <summary class="sc-f-btn"><span class="sc-f-in">Genre…, daneben Jahr und Land, beide
    # bewusst nicht im Menue; Markup gemessen 14.10.2026); bis zum Umbau der Seite am
    # 05.10.2026 hiess der Block „Genres" — das Muster nimmt beide Schreibweisen
    pattern = '>Genres?<.*?</div>'
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'href="([^"]+).*?>([^<]+)')
    if not isMatch:
        cGui().showInfo()
        return

    # Navigations-Einträge filtern (sind schon im Hauptmenü)
    nav_slugs = ['filme', 'filme1', 'kinofilme', 'serien', 'serienstream-deutsch',
                 'kinofilme-online', 'aktuelle-kinofilme-im-kino', 'demnachst',
                 'filme-online-sehen', 'filme-stream', 'neue-filme',
                 'erotik', 'erotikfilme']
    for sUrl, sName in aResult:
        # relative Genre-Pfade (/fantasy/) ueber _absoluteUrl — URL_MAIN endet auf einen
        # Schraegstrich, `URL_MAIN + sUrl` ergab ".//fantasy/"
        sUrl = _absoluteUrl(sUrl)
        slug = sUrl.rstrip('/').split('/')[-1].lower()
        if slug in nav_slugs:
            continue
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def _prefetchDetails(aUrls):
    """Detailseiten einer Liste vorab parallel holen.

    Die Film/Serie-Erkennung in showEntries braucht je Eintrag einen Abruf.
    Sequenziell kostet das Latenz mal Listenlaenge; parallel bleibt es bei rund
    einer Latenz. Der Requesthandler cacht die Antworten, deshalb trifft die
    Einzelpruefung danach den Cache statt das Netz. Fehler werden geschluckt —
    die Einzelpruefung behandelt sie ohnehin selbst.
    """
    # ignoreErrors: das ist ein Hilfsabruf zur Serienerkennung, der Nutzer hat
    # diesen Titel nicht angeklickt. Antwortet die Seite mit 5xx/4xx, zeigte der
    # requestHandler dafuer ein Fehlerfenster — beim Oeffnen einer Genre-Liste
    # bis zu zehn hintereinander (Audit 01.09.2026, 502-Phase einer damals
    # gleich gebauten Schwesterseite: vier Fenster fuer „Drama"). Jetzt
    # schweigt der Abruf, der Eintrag gilt
    # als Film; das Fenster bleibt dem Klick des Nutzers vorbehalten.
    def _fetch(sUrl):
        try:
            # Nur die Seite in den Cache holen: der Serien-Check liest seit dem
            # Plattform-Umbau (28.09.2026) allein die Marker dieser Seite, ein
            # zweiter Abruf faellt weg (siehe _hasMeinecloudSerial).
            cRequestHandler(sUrl, ignoreErrors=True).request()
        except Exception:
            pass  # Fehler behandelt die Einzelpruefung selbst
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as oPool:
        list(oPool.map(_fetch, aUrls))


def _hasMeinecloudSerial(sDetailHtml):
    """Serie oder Film — die Detailseite sagt es selbst.

    Die Seite bettet je Typ ein anderes Plattform-Snippet ein: bei Serien die
    tt-ID im Snippet (`var imdb = '<tt-id>'`) samt dem /serial/-Link, bei Filmen
    den /movie/-Link ohne Snippet-ID. Gemessen am 28.09.2026 auf 12 von 12 Serien-
    und 18 von 18 Filmseiten; die Plattform-API bestaetigt es (tv-Anfragen fuer
    Film-IDs geben 403). Damit braucht die Erkennung keinen Plattform-Abruf mehr —
    der fruehere Check-Endpunkt der Plattform (serials.php) existiert seit dem
    Umbau nicht mehr. Die Staffeln holt spaeter resolveMeinecloudSerial. Die
    Snippet-ID liest platformSnippetId im Wrapper, derselbe Ausdruck wie fuer die
    ID selbst — er kennt auch die rawImdb-Form von hdfilme/kkiste (Begruendung dort).
    """
    if not sDetailHtml or '/serial/' not in sDetailHtml:
        return False
    return bool(platformSnippetId(sDetailHtml))


def _searchUrl(sSearchText, iPage=1, bFull=False):
    """Adresse einer Suchseite. Seite 1 ist die Suchadresse selbst, die Folgeseiten
    blaettern ueber `search_start` — genau das setzt das list_submit-JS der Seite
    (Mitschnitt 21.10.2026: `frm.search_start.value=prm; frm.submit()`).

    Gesucht wird in den TITELN (`titleonly=3`, die Titelsuche der Seite — so
    sucht kinoger schon immer): die Volltextsuche der Seite liefert nach
    Einstelldatum sortierte Beschreibungstreffer, bei „der pate" standen die
    Pate-Filme hinter dem 60er-Deckel der Seite und jede Seite war nach dem
    Titelfilter leer (gemessen 21.10.2026: Titelsuche 8 Treffer auf 2 Seiten
    statt 8 auf 5, „star wars" 33 = 33, „love" 60 statt 51; gleich schnell).
    bFull=True ist die Volltextsuche als Rueckfall, wenn die Titelsuche nichts
    findet — sie trifft z.B. „koenig" fuer „König", die Titelsuche nicht.

    Gebaut wird IMMER aus dem rohen Suchbegriff, nie aus einer fertigen Adresse:
    der Weiter-Eintrag traegt nur Begriff, Seitenzahl und den Rueckfall-Marker,
    weil eine kodierte Adresse den Parameterweg nicht uebersteht (unquote_plus,
    Regel in den Projektregeln) — ein `#` im Begriff wuerde die Adresse sonst
    abschneiden.
    """
    sUrl = URL_SEARCH % cParser.quotePlus(sSearchText)
    if not bFull:
        sUrl += '&titleonly=3'
    if iPage > 1:
        sUrl += '&search_start=%d' % iPage
    return sUrl


def _searchPages(sHtmlContent, iPage):
    """Seitenlage der Suche aus der Blaetterleiste: (hat Folgeseite, letzte Seite).

    Die Suchseite blaettert nicht ueber Links, sondern ueber `list_submit(N)` im
    onclick — die Leiste fuehrt jede andere Seite so, die aktive als <span>, und
    auf der letzten Seite steht keine hoehere Zahl mehr. Die hoechste Zahl ist
    die letzte Seite (die Leiste zeigt sie auch hinter der Auslassung), eine
    hoehere Zahl als die aktive belegt die Folgeseite. Ohne Leiste gibt es nur
    diese eine Seite (gemessen 21.10.2026 ueber 15 Begriffe, Ende 9 von 9 richtig).
    """
    aPages = set(int(x) for x in re.findall(r'list_submit\((\d+)\)', sHtmlContent))
    iLast = max(aPages | {iPage})
    return iLast > iPage, iLast


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not sSearchText:
        # Weiter-Seite der Suche: Kodi ruft die Funktion neu auf, Begriff und
        # Seitenzahl stehen dann nur noch im Parameter. Ohne den Begriff liefe die
        # Folgeseite ungefiltert und zeigte die Beschreibungstreffer der Seite.
        sSearchText = params.getValue('sSearchText') or False
    iPage = 1
    bFull = False
    bNext, iLast = False, 1
    if sSearchText:
        iPage = int(params.getValue('page') or 1)
        bFull = params.getValue('full') == '1'
    elif not entryUrl:
        entryUrl = params.getValue('sUrl')
    pattern = 'class="thumb".*?title="([^"]+).*?href="([^"]+).*?src="([^"]+).*?_year">([^<]+)'
    while True:
        if sSearchText:
            entryUrl = _searchUrl(sSearchText, iPage, bFull)
        # Adressen mit Leerzeichen oder Umlaut kommen aus dem Parameter-Durchlauf
        # unkodiert zurueck -> direkt vor dem Request kodieren (deckt auch die
        # Naechste-Seite-URL ab). Pfadstruktur bleibt erhalten.
        sRequestUrl = cParser.urlEncode(entryUrl, safe="/:?=&%#")
        # Eine Folgeseite der Suche meldet Fehler nicht als Fenster: dort gilt wie
        # beim Blaettern „Kein Eintrag gefunden" (Seite 1 meldet wie bisher).
        oRequest = cRequestHandler(sRequestUrl, ignoreErrors=(sGui is not False or iPage > 1))
        sHtmlContent = oRequest.request()
        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
        if not sSearchText:
            break
        if not isMatch and iPage == 1 and not bFull and sHtmlContent and sHtmlContent not in REQUEST_ERRORS:
            # Die Titelsuche der Seite kennt den Begriff nicht: einmal die
            # Volltextsuche der Seite fragen (Umlaut-Schreibweisen, Begriffe nur
            # in der Beschreibung). Nur bei einer echten Antwort, nie nach einem
            # Fehler — sonst kaeme das Fenster zweimal.
            bFull = True
            continue
        if not isMatch:
            break
        # Titelfilter wie an allen Filterstellen (cParser.searchTitle, normalisiert)
        aResult = [row for row in aResult if cParser.searchTitle(sSearchText, row[0])]
        bNext, iLast = _searchPages(sHtmlContent, iPage)
        if aResult or sGui or not bNext:
            break
        # Seite nach dem Titelfilter leer, aber die Leiste fuehrt eine Folgeseite:
        # gleich weiterblaettern statt dem Nutzer leere Seiten zu zeigen (Jack
        # 21.10.2026 an hdfilme „der pate", fuenf leere Seiten). Nur in der
        # Einzelsuche — die globale Suche bleibt bei Seite 1.
        iPage += 1
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    iShown = 0
    # Die Serien-Erkennung unten braucht je Eintrag die Detailseite. Einzeln in
    # der Schleife abgerufen summiert sich das auf der Leitung (Latenz mal
    # Listenlaenge) — gemessen bei 0,30 s Latenz 8,87 s fuer eine Kategorie mit
    # zwoelf Titeln. Deshalb werden sie VOR der Schleife parallel geholt; die Einzelpruefung
    # trifft danach den HTML-Cache und loest keinen zweiten Netzabruf aus.
    # In der Suche ist die Liste hier schon gefiltert — fuer verworfene Titel
    # wird keine Seite geholt.
    _prefetchDetails([u for n, u, _t, _y in aResult])
    for sName, sUrl, sThumbnail, sYear in aResult:
        if sThumbnail[0] == '/':
            sThumbnail = sThumbnail[1:]
        # In den Parameter gehoert die VOLLE Adresse, nicht der relative Pfad:
        # showSeasons und showEpisodes setzen den Wert unveraendert als Bild, und
        # ein relativer Pfad laesst sich dort nicht laden - die Staffelauswahl blieb
        # ohne Cover, sobald man ueber Suche, Aktuelle Releases, Filme oder Genre in
        # eine Serie ging (belegt 04.09.2026 an "Law & Order"). Ueber showSeries war
        # das Cover da, weil dort schon die volle Adresse weitergereicht wird.
        sThumbAbs = URL_MAIN + sThumbnail

        # Film/Serie via Detail-Seite erkennen (zuverlässigste Quelle bei streamcloud)
        # xStream's Request-Cache macht Wiederholungen instant
        isTvshow = False
        try:
            detailHtml = cRequestHandler(sUrl, ignoreErrors=True).request()   # Hilfsabruf, siehe _prefetchDetails
            # Serie erkannt wenn data-num="NxN" (natives DLE-Pattern) ODER das
            # Plattform-Snippet der Seite eine Serie meldet (_hasMeinecloudSerial).
            # Streamcloud hat seine Serien auf die Plattform umgestellt (kein
            # data-num mehr) — ohne diesen Marker wuerden Plattform-Serien wie
            # "The Rookie" als Film erkannt und direkt in einen Stream springen
            # statt in die Serie.
            isSeriesMatch, _ = cParser.parseSingleResult(detailHtml, r'data-num="\d+x\d+"')
            if not isSeriesMatch:
                isSeriesMatch = _hasMeinecloudSerial(detailHtml)
            if isSeriesMatch:
                isTvshow = True
        except Exception:
            isTvshow = False

        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setThumbnail(sThumbAbs)
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        if sYear: oGuiElement.setYear(sYear)  # Aki: reaktiviert - heutige tmdb/api.py hat getrennte year-Parameter
        params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbAbs)
        params.setParam('sYear', sYear)
        oGui.addFolder(oGuiElement, params, isTvshow, total)
        iShown += 1
        
    if sGui:
        return
    if sSearchText:
        # Suche: eine Seite je Aufruf, die Folgeseite ueber den Weiter-Eintrag mit
        # Begriff, Seitenzahl und Rueckfall-Marker (Bauform wie bei den anderen
        # Seiten). Leere Seiten wurden oben uebersprungen; ohne Treffer und ohne
        # Folgeseite kommt die Meldung „Kein Eintrag gefunden".
        if not iShown:
            oGui.showInfo()
        if bNext:
            nextParams = ParameterHandler()
            nextParams.setParam('sSearchText', sSearchText)
            nextParams.setParam('page', iPage + 1)
            if bFull:
                nextParams.setParam('full', 1)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', nextParams, cGui.pageInfo(iPage, iLast))
    else:
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, 'href="([^"]+)">Next')
        # Seitenlage fuer den Weiter-Eintrag: die hoechste Zahl der Blaetterleiste ist
        # das Listenende — bei langen Listen steht sie hinter der "…"-Auslassung, bei
        # kurzen sind ohnehin alle Zahlen da (gemessen 04.09.2026 gegen die bisektierten
        # Enden, kurz wie lang). Die aktive Seite steht als <span> in derselben Leiste.
        sPageInfo = ''
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="wp-pagenavi(.*?)Next')
        if isMatchSiteSearch:
            isMatchCur, sCurrent = cParser.parseSingleResult(sHtmlContainer, r'<span[^>]*>(\d+)</span>')
            aPages = [int(x) for x in re.findall(r'>(\d{1,6})<', sHtmlContainer)]
            if isMatchCur and aPages:
                sPageInfo = cGui.pageInfo(sCurrent, max(aPages))

        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params, sPageInfo)

    oGui.setView('movies')
    oGui.setEndOfDirectory()


def showSeries(entryUrl=False, sGui=False, sSearchText=False): # Neu eingebaut da auf der Webseite nicht erkennbar ist was Serien sind und was nicht
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = True
    if not entryUrl: entryUrl = params.getValue('sUrl')
    # Adressen mit Leerzeichen oder Umlaut kommen aus dem Parameter-Durchlauf
    # unkodiert zurueck -> direkt vor dem Request kodieren (deckt auch die
    # Naechste-Seite-URL ab). Pfadstruktur bleibt erhalten.
    entryUrl = cParser.urlEncode(entryUrl, safe="/:?=&%#")
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    sHtmlContent = oRequest.request()
    pattern = 'class="thumb".*?title="([^"]+).*?href="([^"]+).*?src="([^"]+).*?_year">([^<]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    iShown = 0
    for sName, sUrl, sThumbnail, sYear in aResult:
        if sSearchText and not cParser.searchTitle(sSearchText, sName):
            continue
        if sThumbnail[0] == '/':
            sThumbnail = sThumbnail[1:]
        sThumbAbs = URL_MAIN + sThumbnail
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
        oGuiElement.setThumbnail(sThumbAbs)
        oGuiElement.setMediaType('tvshow')
        if sYear: oGuiElement.setYear(sYear)  # Aki: reaktiviert - heutige tmdb/api.py hat getrennte year-Parameter
        params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbAbs)
        params.setParam('sYear', sYear)

        oGui.addFolder(oGuiElement, params, isTvshow, total)
        iShown += 1

    # Kamen Treffer an, wurden aber ALLE vom Titelfilter verworfen, stand hier
    # ein leeres Verzeichnis ohne Hinweis (belegt mit "koenig", Audit 01.09.2026).
    # BEWUSST VOR dem Pagination-Block: dessen Bedingung schliesst die Suche aus,
    # die Meldung wuerde dort nie erreicht. Gleiches Muster wie in hdfilme.
    if not sGui and not iShown:
        oGui.showInfo()

    if not sGui and not sSearchText:
        # Beleg ist der Vorwaerts-Link der Seite — dasselbe Muster wie in showEntries.
        # Das frueher hier stehende Muster verlangte >\d[1-9]+< und scheiterte damit an
        # jeder letzten Seitenzahl, die ab der zweiten Stelle eine 0 traegt (damals 506,
        # am 14.10.2026 518):
        # der Weiter-Eintrag fiel komplett weg und die Serienliste endete nach der ersten
        # Seite, obwohl die Quelle ueber 500 Seiten fuehrt. Umgekehrt griff es auf der
        # letzten Seite, wo gar keine Folgeseite mehr existiert.
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, 'href="([^"]+)">Next')
        # Seitenlage fuer den Weiter-Eintrag: die hoechste Zahl der Blaetterleiste ist
        # das Listenende — bei langen Listen steht sie hinter der "…"-Auslassung, bei
        # kurzen sind ohnehin alle Zahlen da (gemessen 04.09.2026 gegen die bisektierten
        # Enden, kurz wie lang). Die aktive Seite steht als <span> in derselben Leiste.
        sPageInfo = ''
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="wp-pagenavi(.*?)Next')
        if isMatchSiteSearch:
            isMatchCur, sCurrent = cParser.parseSingleResult(sHtmlContainer, r'<span[^>]*>(\d+)</span>')
            aPages = [int(x) for x in re.findall(r'>(\d{1,6})<', sHtmlContainer)]
            if isMatchCur and aPages:
                sPageInfo = cGui.pageInfo(sCurrent, max(aPages))
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showSeries', params, sPageInfo)
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


# Poster der Detailseite: genau ein <img itemprop="image" src="/uploads/thumb/300x450-…">
# (DLE-Fullstory, gemessen 03.10.2026 an 60 von 60 Detailseiten, Filme wie Serien). Ein
# og:image-Meta fuehrt die Seite NICHT. Gebraucht, wenn kein Cover mitkommt (Aufruf ohne
# sThumbnail, z.B. alter Favorit) und fuer die Querformat-Karten der Startseite (Szenenbild
# statt Poster) — die Detailseite ist dann ohnehin geladen, es kostet keinen Abruf.
_RE_DETAIL_COVER = re.compile(r'<img\b[^>]*\bitemprop="image"[^>]*>', re.I)


def _detailCover(sHtmlContent):
    """Volle Adresse des Posters aus dem Detail-HTML, sonst ''."""
    m = _RE_DETAIL_COVER.search(sHtmlContent or '')
    mSrc = re.search(r'\bsrc="([^"]+)"', m.group(0)) if m else None
    if not mSrc:
        return ''
    sCover = mSrc.group(1)
    if sCover.startswith('//'):
        return 'https:' + sCover
    return sCover if sCover.startswith('http') else URL_MAIN.rstrip('/') + '/' + sCover.lstrip('/')


def showSeasons():
    """Staffel-Ebene fuer Serien. Native DLE-Serien liefern die Staffeln ueber
    data-num="SxE", meinecloud-Serien ueber die Plattform-API (resolveMeinecloudSerial). Bei genau einer Staffel
    wird die Ordner-Ebene uebersprungen (direkt in die Episoden, HTML/mc werden
    durchgereicht — kein zweiter Request/Lookup)."""
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    sName = params.getValue('sName') if params.exist('sName') else ''
    sThumbnail = params.getValue('sThumbnail')
    sHtmlContent = cRequestHandler(entryUrl).request()
    if not sThumbnail:
        # Kein Cover mitgekommen (Aufruf ohne sThumbnail, z.B. alter Favorit): Poster der
        # Detailseite, und als Parameter weiter, damit auch der Klick auf eine Staffel es hat
        sThumbnail = _detailCover(sHtmlContent)
        if sThumbnail:
            params.setParam('sThumbnail', sThumbnail)

    # Native data-num Staffeln (erste Zahl vor dem 'x')
    isMatch, aNum = cParser.parse(sHtmlContent, r'data-num="(\d+)x\d+"')
    seasons = sorted(set(int(s) for s in aNum)) if isMatch else []

    # meinecloud-Serie: Staffeln aus der Plattform-API
    aMc = []
    if not seasons:
        sImdbId = platformImdbId(sHtmlContent)
        if sImdbId:
            aMc = resolveMeinecloudSerial(sImdbId, referer=entryUrl, siteHtml=sHtmlContent)
            seasons = sorted(set(ep['season'] for ep in aMc))

    if not seasons:
        cGui().showInfo()
        return

    # Nur eine Staffel: Ordner-Ebene sparen, direkt in die Episoden.
    if len(seasons) == 1:
        showEpisodes(staffel=seasons[0], htmlContent=sHtmlContent, mcEpisodes=aMc)
        return

    for iSeason in seasons:
        oGuiElement = cGuiElement(cConfig().getLocalizedString(30512) + ' %d' % iSeason, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setMediaType('season')
        oGuiElement.setSeason(iSeason)
        if sName: oGuiElement.setTVShowTitle(sName)
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        params.setParam('entryUrl', entryUrl)
        params.setParam('staffel', str(iSeason))
        cGui().addFolder(oGuiElement, params, True)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes(staffel=None, htmlContent=None, mcEpisodes=None):
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    sTVShowTitle = params.getValue('sName') if params.exist('sName') else ''   # sName ist unten die Folgenkennung der Schleife
    sThumbnail = params.getValue('sThumbnail')
    # staffel/htmlContent/mcEpisodes werden von showSeasons durchgereicht
    # (Single-Staffel-Skip), sonst kommt die Staffel aus dem Parameter
    # (Klick auf einen Staffel-Ordner).
    if staffel is None and params.exist('staffel'):
        staffel = params.getValue('staffel')
    sStaffel = str(staffel) if staffel is not None else None
    if htmlContent is not None:
        sHtmlContent = htmlContent
    else:
        sHtmlContent = cRequestHandler(entryUrl).request()

    isMatch, aResult = cParser.parse(sHtmlContent, 'data-num="([^"]+)')

    # meinecloud-Episoden: durchgereicht (von showSeasons) oder — falls native
    # Pattern leer — neu laden (Stranger Things etc., Daten nur ueber die Plattform-API).
    aMeinecloudEpisodes = list(mcEpisodes) if mcEpisodes else []
    if not isMatch and not aMeinecloudEpisodes:
        sImdbId = platformImdbId(sHtmlContent)
        if sImdbId:
            aMeinecloudEpisodes = resolveMeinecloudSerial(sImdbId, referer=entryUrl, siteHtml=sHtmlContent)
    if aMeinecloudEpisodes and not isMatch:
        # Format wie Site-Pattern: "<staffel>x<episode>" — kompatibel zu showHosters
        aResult = ['%dx%d' % (ep['season'], ep['episode']) for ep in aMeinecloudEpisodes]

    if not aResult:
        cGui().showInfo()
        return

    # Auf die gewaehlte Staffel filtern (native + meinecloud synchron halten).
    if sStaffel is not None:
        if aMeinecloudEpisodes:
            filtered = [(ep, sNum) for ep, sNum in zip(aMeinecloudEpisodes, aResult) if str(ep['season']) == sStaffel]
            aMeinecloudEpisodes = [ep for ep, sNum in filtered]
            aResult = [sNum for ep, sNum in filtered]
        else:
            aResult = [sNum for sNum in aResult if sNum.split('x')[0] == sStaffel]
        if not aResult:
            cGui().showInfo()
            return

    # Falls kein Parent-Thumbnail uebergeben (z.B. alter Favorit): Poster der Detailseite
    if not sThumbnail:
        sThumbnail = _detailCover(sHtmlContent)

    total = len(aResult)
    for i, sName in enumerate(aResult):
        # Eine Form auf allen Sites ("S01E11 - Titel", cParser.episodeLabel): im meinecloud-Mode mit dem
        # Folgentitel der Plattform, sonst aus der Folgenkennung der Seite ("1x5"; eine andere Form bleibt stehen)
        if aMeinecloudEpisodes:
            ep = aMeinecloudEpisodes[i]
            sLabel = cParser.episodeLabel(ep['season'], ep['episode'], ep['title'])
        else:
            sSeasonNr, _, sEpisodeNr = sName.partition('x')
            sLabel = cParser.episodeLabel(sSeasonNr, sEpisodeNr, '', sName)
        oGuiElement = cGuiElement(sLabel, SITE_IDENTIFIER, 'showHosters')
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setMediaType('episode')
        if sTVShowTitle: oGuiElement.setTVShowTitle(sTVShowTitle)
        if aMeinecloudEpisodes:
            oGuiElement.setSeason(ep['season'])
            oGuiElement.setEpisode(ep['episode'])
        params.setParam('entryUrl', entryUrl)
        params.setParam('episode', sName)
        # meinecloud-Mode: alle Quellen der Folge mitgeben (ein Parameter, packSourceUrls),
        # damit showHosters() ohne weiteren Lookup aufloest
        if aMeinecloudEpisodes:
            params.setParam('meinecloud_url', packSourceUrls(aMeinecloudEpisodes[i]['urls']))
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def _resolvePlayerWrapper(wrapperUrl):
    """Löst einen streamcloud-internen /player/... Wrapper zu einer echten Hoster-URL auf."""
    try:
        oRequest = cRequestHandler(wrapperUrl)
        oRequest.addHeaderEntry('Referer', URL_MAIN)
        wrapperHtml = oRequest.request()
        # Innerhalb des Wrappers stehen iframes oder direkte Hoster-URLs
        # Pattern: iframe src=, oder data-link= mit http(s)
        isMatch, aResult = cParser.parse(wrapperHtml, r'<iframe[^>]+src="(https?://[^"]+)"')
        if isMatch and aResult:
            return aResult[0]
        isMatch, aResult = cParser.parse(wrapperHtml, r'data-link="(https?://[^"]+)"')
        if isMatch and aResult:
            return aResult[0]
    except Exception:
        pass
    return None


def showHosters():
    # Endet ohne Hoster OHNE eigene Meldung (alle vier Rueckspruenge unten): hoster.py meldet die leere
    # Liste selbst mit „Stream // Hoster nicht verfuegbar" (30141). Das eigene „Kein Eintrag gefunden"
    # war die zweite Einblendung fuer denselben Klick — Full Audit 27.10.2026 an einem Serien-Eintrag,
    # der nach gescheitertem Detail-Vorlauf als Film in der Liste stand (Seite ohne Player-iframe).
    # Dieselbe Regel wie beim Sprach-Hinweis (cGui.showLanguage).
    hosters = []
    sUrl = ParameterHandler().getValue('entryUrl')
    sMeinecloudUrl = ParameterHandler().getValue('meinecloud_url') if ParameterHandler().exist('meinecloud_url') else ''

    # meinecloud-Mode: die Adressen kommen direkt aus showEpisodes (alle Quellen der
    # Folge in einem Parameter, unpackSourceUrls), kein DLE-HTML-Parsing noetig.
    if sMeinecloudUrl:
        for sMcUrl in unpackSourceUrls(sMeinecloudUrl):
            _fixedUrl = ('https:' + sMcUrl) if sMcUrl.startswith('//') else sMcUrl
            sName = cParser.urlparse(_fixedUrl).split('.')[0].strip()
            if not cConfig().isBlockedHoster(sName)[0]:
                hosters.append({'link': _fixedUrl, 'name': sName, 'displayedName': sName})
        if hosters:
            hosters.append('getHosterUrl')
        return hosters

    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    if ParameterHandler().exist('episode'): #kommt aus showSeries
        episode = ParameterHandler().getValue('episode')
        # Ganzen <li>-Block für diese Episode holen (primary + alle mirrors)
        # Struktur: <li><a data-num="NxN">...</a><div class="mirrors"><a data-m="..." data-link="...">...</a>...</div></li>
        blockPattern = r'<li>\s*<a [^>]*data-num="{0}".*?</li>'.format(episode)
        isMatch, sBlock = cParser.parseSingleResult(sHtmlContent, blockPattern)
        if not isMatch:
            return
        # Native DLE-Serien (data-num) sind auf der Seite seit der Umstellung auf meinecloud
        # kaum noch zu finden (Stichproben 02.09.2026: keine) — dieser Zweig bleibt fuer den
        # Altbestand. Echte HTML-Kommentare (<!-- ... -->) entfernen damit disablte Mirrors rausfliegen.
        # Aber NICHT <!--- ... ---> (drei Dashes) matchen — Streamcloud nutzt das Format
        # fuer "soft-disabled" Mirrors (z.B. Dropload). Falls Site-Owner sie reaktiviert,
        # sind sie automatisch verfuegbar ohne Code-Touch.
        sBlock = re.sub(r'<!--(?!-)(.*?)(?<!-)-->', '', sBlock, flags=re.DOTALL)
        # Alle data-link sammeln (externe + interne Player-Wrapper)
        isMatch, aResult = cParser.parse(sBlock, r'data-link="([^"]+)"')
        if not isMatch:
            return
        # Interne /player/... URLs auflösen, externe direkt übernehmen
        resolvedLinks = []
        seen = set()
        for link in aResult:
            if link.startswith('/'):
                # Interner Player-Wrapper → zu echter Hoster-URL auflösen
                fullWrapperUrl = URL_MAIN + link.lstrip('/')
                realUrl = _resolvePlayerWrapper(fullWrapperUrl)
                if realUrl and realUrl not in seen:
                    seen.add(realUrl)
                    resolvedLinks.append(realUrl)
            elif link.startswith('http') and link not in seen:
                seen.add(link)
                resolvedLinks.append(link)
        aResult = resolvedLinks
        if not aResult:
            return
        isMatch = True
    else:
        # Aufs Tag begrenzt: der alte offene Schnitt ('<iframe.*?allowfull') lief
        # bei einem iframe OHNE allowfull-Attribut bis zum naechsten allowfull im
        # Dokument weiter und haette dann ein fremdes src gegriffen — dieselbe
        # Fallenklasse wie ein offener serial_iframe-Schnitt. Die Player-iframes
        # der Seite tragen allowfullscreen im Tag, fuer die aendert sich nichts.
        pattern = '<iframe[^>]*allowfull'
        isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
        if isMatch:
            isMatch, aResult = cParser.parse(sHtmlContainer, 'src="([^"]+)')
            try:
                sUrl = aResult[0]
            except:
                pass
        if not isMatch:
            return
        if isPlatformUrl(sUrl):
            # Plattform-iframe (meinecloud/devideosrc): Laden und Aufloesen macht
            # resolveMeinecloud() zentral — Token-Seite plus JSON-API der Plattform,
            # ohne Cache, weil der Token nur kurz gilt. Der Selbst-Parse darunter
            # griffe bei der Plattform ins Leere (keine data-links im HTML seit ihrem
            # Umbau am 28.09.2026). Das expandHosterList am Konvergenzpunkt unten
            # laeuft fuer diese schon finalen URLs als reiner Dedupe-Durchlauf ohne
            # weiteren Netzabruf.
            aResult = expandHosterList([sUrl], referer=URL_MAIN)
            isMatch = bool(aResult)
        else:
            sHtmlContent = cRequestHandler(sUrl).request()
            isMatch, aResult = cParser.parse(sHtmlContent, 'data-link="([^"]+)')
    if isMatch:
        sQuality = '720'
        # Meinecloud-Wrapper expandieren: streamcloud versteckt zusaetzliche Hoster
        # hinter meinecloud-URLs (siehe resources/lib/wrappers/meinecloud.py). Page liefert eigene data-link Liste.
        # Greift fuer beide Modi (Episode + Movie konvergieren hier).
        aResult = expandHosterList(aResult, referer=URL_MAIN)

        for sUrl in aResult:
            if not sUrl or not sUrl.strip(): continue   # Leere data-link skippen (z.B. meinecloud "andere Server" Toggle)
            hoster = buildHosterFromUrl(sUrl, sQuality=sQuality, includeQualitySuffix=True)
            if hoster:
                hosters.append(hoster)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    win = xbmcgui.Window(10000)
    sSearchText = win.getProperty('klarfilm.streamcloud.lastSearchText')
    if not sSearchText:
        sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30287))
        if not sSearchText: return
        win.setProperty('klarfilm.streamcloud.lastSearchText', sSearchText)
    # Das Verzeichnis schliesst showEntries selbst ab — so wie bei jeder
    # Weiter-Seite der Suche, die Kodi direkt dort aufruft.
    _search(False, sSearchText)


def _search(oGui, sSearchText):
    showEntries(_searchUrl(sSearchText), oGui, sSearchText)


