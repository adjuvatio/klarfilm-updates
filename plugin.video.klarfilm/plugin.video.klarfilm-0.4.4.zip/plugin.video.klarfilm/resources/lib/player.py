# -*- coding: utf-8 -*-
# Python 3

import time
import urllib.request
from urllib.parse import parse_qsl

import xbmc
from resources.lib.gui.gui import cGui
from resources.lib.config import cConfig
from resources.lib.logger import logger

# Dateiendungen, bei denen die Adresse sicher kein HLS ist: dort entfaellt die
# Inhaltspruefung, der native Player spielt die Datei.
_NO_HLS_EXTENSIONS = ('.mp4', '.mkv', '.avi', '.webm', '.mov', '.flv')
# Dateiendungen, unter denen Hoster ihre Playlists fuehren: dort ist es HLS, die
# Inhaltspruefung entfaellt. Grund: scheiterte die Pruefung an einer langsamen
# Antwort, ging die Playlist an den nativen Player, Kodis Demuxer las sie als
# Textvideo, das sofort endet — und das zaehlte als Start, der Auto-Modus blieb
# stehen (`master.txt`, Pruefstand 28.10.2026).
_HLS_EXTENSIONS = ('.txt',)
# Wartezeit der Inhaltspruefung; ein Fehler oder Ablauf zaehlt als "kein HLS" und die
# Adresse geht an den nativen Player. 6 s (bis 28.10.2026 8 s, Jack): beantwortete
# Pruefungen brauchten gemessen 0,3–2,9 s (Handy 16.10.2026, Pruefstand 28.10.2026).
_PROBE_TIMEOUT = 6


def _isHlsContent(url, headerString):
    # HLS ohne .m3u8 in der Adresse am Inhalt erkennen: eine Playlist beginnt
    # mit #EXTM3U. Nur der Anfang wird gelesen — ueber den cRequestHandler
    # kaeme die ganze Antwort, bei einem MP4 ohne Endung der ganze Film.
    # Der Content-Type reicht nicht, die Hoster liefern Playlists auch als
    # text/plain (gemessen 15.10.2026). Rueckgabe: Ergebnis und ein Wort fuer
    # die Log-Zeile.
    if not url.lower().startswith(('http://', 'https://')):
        return False, 'Pruefung nur bei http'
    headers = dict(parse_qsl(headerString)) if headerString else {}
    if not any(key.lower() == 'user-agent' for key in headers):
        # Ohne User-Agent in der Pipe ruft ISA ueber Kodis Dateizugriff mit
        # Kodis eigenem ab; die Pruefung fragt mit demselben, damit der Server
        # beide Abrufe gleich behandelt (gemessen 15.10.2026).
        headers['User-Agent'] = xbmc.getUserAgent()
    start = time.time()
    try:
        request = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(request, timeout=_PROBE_TIMEOUT) as response:
            head = response.read(1024)
    except Exception as e:
        return False, 'Pruefung %s nach %.2f s' % (type(e).__name__, time.time() - start)
    isHls = head.lstrip(b'\xef\xbb\xbf \r\n\t').startswith(b'#EXTM3U')
    return isHls, 'Inhalt, %.2f s' % (time.time() - start)


def applyIsa(list_item, link):
    # HLS laeuft ueber InputStream Adaptive (ISA), sobald das Addon installiert
    # und aktiv ist; sonst bleibt alles beim nativen Player, auch das ListItem.
    # Grund: Kodis eigener Demuxer (FFmpeg) weist Playlists und Segmente mit
    # fremder Dateiendung ab (.js, .txt, .woff2 — so tarnen Hoster wie Gupload,
    # Vidara, Playmate, GXPlayer oder Moflix-Stream ihre Streams), ISA liest
    # sie. Kein eigener Schalter und keine Versionsabfrage: ist ISA da, wird es
    # genutzt, ist es weg oder aus, laeuft es wie vorher.
    # Rueckgabe: die Adresse fuer play() bzw. die Playlist, und ob ISA greift.
    # Die Log-Zeile nennt die Adresse ohne die Header der Pipe.
    url, _sep, headerString = link.partition('|')
    if not xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.adaptive)'):
        logger.info('-> [player]: ISA nicht aktiv, Wiedergabe nativ: %s' % url)
        return link, False
    if '.m3u8' in link or url.lower().split('?')[0].endswith(_HLS_EXTENSIONS):
        isHls, how = True, 'Endung'
    elif url.lower().split('?')[0].endswith(_NO_HLS_EXTENSIONS):
        isHls, how = False, 'Endung'
    else:
        isHls, how = _isHlsContent(url, headerString)
    if not isHls:
        logger.info('-> [player]: kein HLS (%s), Wiedergabe nativ: %s' % (how, url))
        return link, False
    # Pfad ohne Pipe: neuere ISA schneidet die Pipe selbst ab, aeltere reicht
    # sie an Kodis Dateizugriff weiter, der die Header nur fuer den ersten
    # Playlist-Abruf setzt — Child-Playlist und Segmente bekaemen sie nicht
    # (ISA-Quelltext, 15.10.2026).
    list_item.setPath(url)
    list_item.setProperty('inputstream', 'inputstream.adaptive')
    if headerString:
        # Kodi reicht an ISA nur Properties durch, die ISA selbst anmeldet;
        # jede ISA-Generation kennt eine andere Auswahl (ISA-Quelltext,
        # 15.10.2026). Derselbe Header-String steht deshalb in allen vier:
        # - manifest_headers / stream_headers: Playlists bzw. Segmente, ueberall
        # - common_headers: nur neuere ISA, dort an jeden Abruf, auch an den
        #   AES-Schluessel
        # - license_key "|Header": aeltere ISA holt den AES-Schluessel nur mit
        #   den Headern aus dem Teil nach der Pipe; ohne license_type startet
        #   keine DRM-Sitzung, neuere ISA ueberspringt die Property still.
        # Belegt an LuluStream: der Schluessel-Abruf ohne Header endet mit 403,
        # mit dieser Form spielt der Hoster auf beiden ISA-Generationen
        # (gemessen 15.10.2026).
        list_item.setProperty('inputstream.adaptive.manifest_headers', headerString)
        list_item.setProperty('inputstream.adaptive.stream_headers', headerString)
        list_item.setProperty('inputstream.adaptive.common_headers', headerString)
        list_item.setProperty('inputstream.adaptive.license_key', '|' + headerString)
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    logger.info('-> [player]: HLS (%s), Wiedergabe ueber ISA: %s' % (how, url))
    return url, True


class XstreamPlayer(xbmc.Player):
    # Ein Exemplar je Abspielversuch. Als Erfolg zaehlt nur onAVStarted (Bild
    # und Ton laufen). onPlayBackStarted taugt dafuer nicht: Kodi meldet es
    # schon beim Oeffnen der Datei, auch wenn das Oeffnen danach scheitert
    # (VideoPlayer::OpenFile). Ein Fehlstart endet mit onPlayBackStopped
    # (Fehler beim Oeffnen) oder onPlayBackEnded (Stream ohne Inhalt, etwa eine
    # leere Playlist) — jeweils ohne onAVStarted davor.
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self, *args, **kwargs)
        self.streamFinished = False
        self.avStarted = False
        logger.debug('player instance created')

    def onPlayBackStarted(self):
        logger.debug('starting Playback')

    def onAVStarted(self):
        if self.streamFinished:
            return
        logger.debug('AV started')
        self.avStarted = True

    def onPlayBackStopped(self):
        self._finish('Playback stopped')

    def onPlayBackEnded(self):
        self._finish('Playback completed')

    def onPlayBackError(self):
        # Einen Fehlstart meldet Kodi an Python als onPlayBackStopped
        # (CApplicationPlayerCallback::OnPlayBackError); dieser Rueckruf kommt
        # dort derzeit nicht an. Er bleibt als Absicherung, falls sich das
        # aendert.
        self._finish('Playback error')

    def _finish(self, message):
        # Ist dieser Versuch schon beendet, gehoeren weitere Meldungen zu einer
        # spaeteren Wiedergabe (die Exemplare leben bis zum Skriptende, siehe
        # cPlayer._players) und werden hier nicht mehr gewertet.
        if self.streamFinished:
            return
        logger.debug(message)
        if not self.avStarted:
            logger.error('Kodi failed to open stream')
        self.streamFinished = True



class cPlayer:
    # Alle Player-Exemplare eines Skriptlaufs bleiben bis zum Skriptende
    # erhalten. Grund ist Kodis neue SWIG-Python-Anbindung (sie loeste die
    # Groovy-erzeugte ab): beim Freigeben eines Exemplars einer
    # xbmc.Player-Unterklasse gibt sie den Verweis auf die Klasse nicht frei.
    # Die Klasse und alles, was ueber ihr Modul erreichbar ist (bis zum
    # Addon-Objekt in cConfig), ueberlebt dann das Skriptende — im Kodi-Log
    # "left several classes in memory ... Addon", und der Speicher waechst mit
    # jeder Wiedergabe. Werden die Exemplare erst beim Abbau des Interpreters
    # frei, raeumt Kodi sie mit dem Rest ab. Ueber Aufrufe hinweg waechst die
    # Liste nicht: Kodi startet xStream je Aufruf in einem frischen Interpreter.
    # Dasselbe Muster gilt fuer den Trailer-Player (trailer.py, _TrailerPlayer)
    # und das Info-Fenster (tmdb/info.py, WindowsBoxes).
    _players = []

    def clearPlayList(self):
        oPlaylist = self.__getPlayList()
        oPlaylist.clear()

    def __getPlayList(self):
        return xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

    def addItemToPlaylist(self, oGuiElement):
        oListItem = cGui().createListItem(oGuiElement)
        self.__addItemToPlaylist(oGuiElement, oListItem)

    def __addItemToPlaylist(self, oGuiElement, oListItem):
        oPlaylist = self.__getPlayList()
        sUrl, _isa = applyIsa(oListItem, oGuiElement.getMediaUrl())
        oPlaylist.add(sUrl, oListItem)

    def startPlayer(self, isa=False, untilAv=False):
        # isa: der Versuch laeuft ueber InputStream Adaptive, dessen eigenes
        # Fehlerfenster wird geschlossen (unten). untilAv: nur bis zum ersten
        # Bild warten statt bis zum Ende der Wiedergabe — fuer Live-TV, wo das
        # Skript sonst beim Umschalten bis zum Stopp offen bliebe (gemessen
        # 15.10.2026). Der Rueckgabewert bleibt in beiden Faellen avStarted.
        logger.debug('start player')
        xbmcPlayer = XstreamPlayer()
        cPlayer._players.append(xbmcPlayer)
        monitor = xbmc.Monitor()
        startup_deadline = time.monotonic() + 25
        while (not monitor.abortRequested()) and (not xbmcPlayer.streamFinished) \
                and not (untilAv and xbmcPlayer.avStarted):
            # Die Rueckrufe laufen waehrend waitForAbort; die Schleife merkt
            # das Ende eines Versuchs erst, wenn der Aufruf zurueckkehrt. Ein
            # kurzer Takt haelt die Wartezeit bis zum naechsten Hoster klein
            # und kostet waehrend der Wiedergabe nichts Messbares.
            monitor.waitForAbort(0.25)
            if not xbmcPlayer.avStarted and time.monotonic() >= startup_deadline:
                xbmcPlayer.streamFinished = True
                xbmcPlayer.stop()
                logger.warning('Klarfilm: Wiedergabestart nach 25 Sekunden abgebrochen')
                break
            # Neuere ISA zeigt bei einer fehlenden oder leeren Playlist ein
            # eigenes OK-Fenster, waehrend der Player noch oeffnet; bis jemand
            # OK drueckt, haengt das Oeffnen. Es wird geschlossen, solange der
            # Player oeffnet (isPlaying) und noch kein Bild da ist. Kodis
            # eigenes "Wiedergabe fehlgeschlagen" kommt erst nach dem Stopp
            # und bleibt wie bisher stehen. Die Beschriftung wird nicht
            # gelesen: ein frisch geoeffnetes Fenster traegt fuer einen
            # Bildaufbau noch die des vorigen (gemessen 15.10.2026).
            if isa and not xbmcPlayer.avStarted and not xbmcPlayer.streamFinished \
                    and xbmc.getCondVisibility('Window.IsActive(okdialog)') and xbmcPlayer.isPlaying():
                xbmc.executebuiltin('Dialog.Close(okdialog,true)')
        return xbmcPlayer.avStarted