# GPL-3.0-or-later. Shared dependencies are maintained by Kodi repositories.
from resources.lib.tools import infoDialog

def resolverUpdate():
    return None

def manualResolverUpdate():
    infoDialog('ResolveURL über die Kodi-Add-on-Verwaltung aktualisieren', sound=False)
