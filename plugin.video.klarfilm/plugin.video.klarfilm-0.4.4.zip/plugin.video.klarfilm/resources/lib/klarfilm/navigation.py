"""GPL-3.0-or-later. Own Kodi panel; does not depend on the active skin's folder view."""
from pathlib import Path
from resources.lib.klarfilm.appearance import artwork

def show_navigation(entries, addon, profile, view='home'):
    import xbmcgui
    root = addon.getAddonInfo('path')
    brand = Path(root) / 'resources/art/brand/v2'
    titles = {'home':'Dein Kino. Deine Serien.', 'library':'Meine Mediathek',
              'discover':'Entdecken', 'search_menu':'Suche',
              'providers':'Anbieter & Verbindungen', 'new_episodes':'Neue Serienfolgen'}
    class Navigation(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.selected = None
        def onInit(self):
            self.setProperty('klarfilm.background', str(brand / 'backdrop.png'))
            self.setProperty('klarfilm.logo', str(brand / 'clearlogo.png'))
            self.setProperty('klarfilm.title', titles.get(view, 'Klarfilm'))
            self.setProperty('klarfilm.subtitle', profile + ' · ' + addon.getAddonInfo('version'))
            items = []
            for label, path in entries:
                item = xbmcgui.ListItem(label)
                item.setArt(artwork(root, path))
                items.append(item)
            panel = self.getControl(9000)
            panel.reset()
            panel.addItems(items)
            self.setFocusId(9000)
        def onClick(self, control):
            if control == 9000:
                position = self.getControl(9000).getSelectedPosition()
                if 0 <= position < len(entries):
                    self.selected = entries[position][1]
                    self.close()
        def onAction(self, action):
            if action.getId() in (9, 10, 92, 216, 247, 257):
                self.close()
    window = Navigation('KlarfilmHome.xml', root, 'Default', '1080i')
    window.doModal()
    selected = window.selected
    del window
    return selected
