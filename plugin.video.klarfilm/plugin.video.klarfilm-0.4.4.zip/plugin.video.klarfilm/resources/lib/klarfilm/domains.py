"""GPL-3.0-or-later. Domain checks without Kodi imports, cookies or credentials."""
import re
import time
import socket
import ssl
import ipaddress
from urllib.parse import urlsplit, urljoin
from urllib.request import Request, build_opener, HTTPRedirectHandler, HTTPSHandler
from urllib.error import HTTPError, URLError

# Confirmed on the provider's own footer, 2026-11-08. Do not guess new TLDs.
# https://serienstream.to/faqs/11120-sto-geht-nicht-mehr
ALIASES = {'serienstream': ('serienstream.to', 'serienstream.cx')}
BLOCKED = ('cuii.info', 'alliance4creativity.com', 'site-maps.cc')
PARKED = ('domain is for sale', 'buy this domain', 'domain parking', 'sedoparking')


def host(value):
    try:
        parsed = urlsplit(value if '://' in value else 'https://' + value)
        name = (parsed.hostname or '').rstrip('.').lower().encode('idna').decode()
        if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port not in (None, 443):
            return ''
        if not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?', name) or '.' not in name:
            return ''
        if name.endswith(('.local', '.internal', '.localhost')) or any(name == b or name.endswith('.' + b) for b in BLOCKED):
            return ''
        try:
            ipaddress.ip_address(name)
            return ''  # IP-only mirrors cannot establish provider identity over HTTPS.
        except ValueError:
            return name
    except (ValueError, UnicodeError):
        return ''


def normalized(value):
    return re.sub('[^a-z0-9]', '', value.casefold())


def identity(spec, body):
    text = body.casefold()
    if spec['id'] == 'serienstream':
        return 'serienstream' in normalized(text) and '/serien' in text and '/neue-episoden' in text
    title = re.search(r'<title[^>]*>(.*?)</title>', text, re.S)
    if not title:
        return False
    wanted = [normalized(spec['id']), normalized(spec['name'])]
    return any(len(word) >= 4 and word in normalized(title.group(1)) for word in wanted)


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def fetch(url, timeout):
    # Every request is anonymous and TLS-verified. No resolver or challenge bypass.
    opener = build_opener(NoRedirect(), HTTPSHandler(context=ssl.create_default_context()))
    request = Request(url, headers={'User-Agent': 'Klarfilm/0.4.2 DomainCheck', 'Accept': 'text/html'})
    try:
        response = opener.open(request, timeout=timeout)
    except HTTPError as error:
        response = error
    with response:
        if response.code in (301, 302, 303, 307, 308):
            return response.code, dict(response.headers.items()), ''
        deadline = time.monotonic() + timeout
        chunks, size = [], 0
        while size < 262144:
            if time.monotonic() >= deadline:
                raise socket.timeout('Domain response exceeded its time budget')
            part = response.read1(min(16384, 262144 - size))
            if not part:
                break
            chunks.append(part)
            size += len(part)
        return response.code, dict(response.headers.items()), b''.join(chunks).decode('utf-8', 'replace')


def check(spec, request=fetch, stopped=lambda: False, clock=time.monotonic, budget=18):
    deadline = clock() + budget
    candidates = list(dict.fromkeys(h for h in [host(spec['current']), host(spec['default']), *ALIASES.get(spec['id'], ())] if h))
    result = {'id': spec['id'], 'previous': spec['current'], 'domain': '', 'status': '-3', 'detail': 'Keine Verbindung', 'checked': time.time()}
    for candidate in candidates:
        if stopped() or clock() >= deadline:
            break
        url = 'https://' + candidate + '/'
        redirected = False
        seen = set()
        try:
            for _ in range(4):
                if stopped() or clock() >= deadline:
                    return None
                if url in seen or not host(url):
                    result.update(status='0', detail='Umleitung nicht bestätigt')
                    break
                seen.add(url)
                code, headers, body = request(url, min(3, max(.1, deadline - clock())))
                lower = body.casefold()
                header = {k.casefold(): v for k, v in headers.items()}
                if header.get('cf-mitigated', '').casefold() == 'challenge' or any(p in lower for p in ('cf-chl-', 'challenge-platform', 'just a moment...', 'ddos-guard')):
                    result.update(status='-4' if 'ddos-guard' not in lower else '-2', detail='Durch Sicherheitsprüfung blockiert')
                    break
                if code in (301, 302, 303, 307, 308):
                    target = urljoin(url, header.get('location', ''))
                    if not header.get('location') or not host(target):
                        result.update(status='0', detail='Umleitung nicht bestätigt')
                        break
                    url = target
                    redirected = True
                    continue
                if code == 200 and not any(p in lower for p in PARKED):
                    # A familiar domain must still return recognisable provider content.
                    # Cross-domain redirects receive the same identity check.
                    if not identity(spec, body):
                        result.update(status='0', detail='Anbieterinhalt nicht bestätigt')
                        break
                    result.update(domain=host(url), status='200', detail='Startseite bestätigt' + (' nach Weiterleitung' if redirected else ''))
                    return result
                result.update(status=str(code) if code != 200 else '0', detail='HTTP ' + str(code) if code != 200 else 'Domain geparkt')
                break
        except (socket.timeout, TimeoutError):
            result.update(status='-1', detail='Zeitüberschreitung')
        except (OSError, URLError, ssl.SSLError):
            # Keep a detected challenge visible when another alias merely fails.
            if result['status'] not in ('-4', '-2'):
                result.update(status='-3', detail='Keine Verbindung')
    return None if stopped() else result


def plans(root, setting):
    from pathlib import Path
    import xml.etree.ElementTree as ET
    from resources.lib.klarfilm.startup import inventory
    defaults = {s.get('id'): s.findtext('default', '') for s in ET.parse(Path(root) / 'resources/settings.xml').iter('setting')}
    items = inventory(root, setting)
    shipped = {p['id']: p['domain'] for p in inventory(root, lambda _: '')}
    result = []
    for item in items:
        key = 'plugin_' + item['id'] + '_checkDomain'
        if not item['enabled'] or (setting(key) or defaults.get(key, '')).casefold() != 'true':
            continue
        # inventory's domain already includes a manual override; obtain the shipped
        # default separately so an obsolete override never hides recovery options.
        default = shipped[item['id']]
        result.append(dict(id=item['id'], name=item['name'], current=setting('plugin_' + item['id'] + '.domain'), default=default))
    return result


def apply(result, setting, save, manual=False):
    if not result:
        return False
    site = result['id']
    if (not manual and setting('klarfilm.domains_auto') == 'false') or setting('plugin_' + site) == 'false' or setting('plugin_' + site + '_checkDomain') == 'false':
        return False
    key = 'plugin_' + site + '.domain'
    if setting(key) != result['previous']:
        return False  # The user changed it while the network check was running.
    status_key = 'plugin_' + site + '_status'
    if setting(status_key) != result['status']:
        save(status_key, result['status'])
    if result['domain'] and setting(key) != result['domain']:
        save(key, result['domain'])
    return True
