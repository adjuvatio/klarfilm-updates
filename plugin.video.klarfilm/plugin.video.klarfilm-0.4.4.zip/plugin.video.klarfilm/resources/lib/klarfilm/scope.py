"""GPL-3.0-or-later. Pure account/profile namespace and transport validation."""
import hashlib
from pathlib import Path
import re
from urllib.parse import urlsplit, urlunsplit


def secure_server(url):
    parsed = urlsplit(str(url).strip().rstrip('/'))
    if parsed.username or parsed.password or parsed.query or parsed.fragment or not parsed.hostname:
        raise ValueError('Ungültige Server-Adresse')
    if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in ('127.0.0.1', 'localhost', '::1', '10.77.0.1')):
        raise ValueError('Für Kontozugänge HTTPS oder die interne WireGuard-Adresse verwenden')
    # Accessing port also validates malformed port numbers.
    port = parsed.port
    host = parsed.hostname.lower()
    host = '[' + host + ']' if ':' in host else host
    return urlunsplit((parsed.scheme, host + (':' + str(port) if port else ''), parsed.path.rstrip('/'), '', ''))


def validate_context(context):
    if not context:
        return {}
    result = dict(context)
    result['server'] = secure_server(result['server'])
    for field in ('account_id', 'profile_id', 'device_id'):
        if not isinstance(result.get(field), str) or not re.fullmatch(r'[0-9a-f]{32}', result[field]):
            raise ValueError('Ungültiger Konto-/Profilkontext')
    if not isinstance(result.get('token'), str) or not 32 <= len(result['token']) <= 128:
        raise ValueError('Geräteanmeldung fehlt')
    return result


def context_key(context):
    context = validate_context(context)
    if not context:
        return 'local'
    server = hashlib.sha256(context['server'].encode()).hexdigest()[:24]
    return ':'.join((server, context['account_id'], context['profile_id']))


def account_directory(root, context):
    context = validate_context(context)
    if not context:
        return Path(root)
    server = hashlib.sha256(context['server'].encode()).hexdigest()[:24]
    return Path(root) / 'households' / server / context['account_id']


def state_path(root, context):
    context = validate_context(context)
    if not context:
        return Path(root) / 'klarfilm.sqlite'
    return account_directory(root, context) / 'profiles' / context['profile_id'] / 'klarfilm.sqlite'
