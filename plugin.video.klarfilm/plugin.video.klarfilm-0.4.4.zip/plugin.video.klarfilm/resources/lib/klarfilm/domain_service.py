"""GPL-3.0-or-later. Network workers return data; only Kodi's service thread writes settings."""
import queue
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from resources.lib.klarfilm.domains import check, plans, apply


class DomainService:
    def __init__(self, addon, clock=time.monotonic, manual=False):
        self.addon = addon
        self.manual = manual
        self.clock = clock
        self.created = clock()
        self.stop = threading.Event()
        self.results = queue.Queue()
        self.worker = None
        self.started = False
        self.retry = set()
        self.retried = False

    def tick(self):
        while True:
            try:
                result = self.results.get_nowait()
            except queue.Empty:
                break
            if result and apply(result, self.addon.getSetting, self.addon.setSetting, manual=self.manual):
                if result['status'] in ('-1', '-3'):
                    self.retry.add(result['id'])
        if self.stop.is_set() or self.addon.getSetting('klarfilm.domains_auto') == 'false':
            return
        age = self.clock() - self.created
        if not self.started and age >= 20:
            self.started = True
            self.start()
        elif self.started and not self.retried and age >= 120 and (self.worker is None or not self.worker.is_alive()):
            self.retried = True
            if self.retry:
                self.start(self.retry)

    def start(self, only=None):
        # This snapshot calls Kodi exclusively on the service thread.
        specs = plans(self.addon.getAddonInfo('path'), self.addon.getSetting)
        if only is not None:
            specs = [s for s in specs if s['id'] in only]
        def work():
            deadline = time.monotonic() + 45
            def cancelled():
                return self.stop.is_set() or time.monotonic() >= deadline
            def probe(spec):
                if cancelled():
                    return
                try:
                    result = check(spec, stopped=cancelled)
                    if result:
                        self.results.put(result)
                except Exception:
                    self.results.put(dict(id=spec['id'], previous=spec['current'], domain='', status='0', detail='Prüfung fehlgeschlagen'))
            with ThreadPoolExecutor(max_workers=2) as executor:
                futures = [executor.submit(probe, spec) for spec in specs]
                for future in futures:
                    if self.stop.is_set():
                        for pending in futures:
                            pending.cancel()
                        break
                    future.result()
        self.worker = threading.Thread(target=work, name='KlarfilmDomains', daemon=False)
        self.worker.start()

    def close(self):
        self.stop.set()
        if self.worker:
            self.worker.join()


def manual_check():
    import xbmc
    import xbmcaddon
    from resources.lib.klarfilm.startup import refresh_report
    runner = DomainService(xbmcaddon.Addon(), manual=True)
    runner.started = runner.retried = True
    runner.start()
    monitor = xbmc.Monitor()
    try:
        while runner.worker.is_alive():
            runner.tick()
            if monitor.waitForAbort(.2):
                break
        runner.tick()
        refresh_report()
    finally:
        runner.close()
