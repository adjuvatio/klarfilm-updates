"""GPL-3.0-or-later. Episode continuation and thread-safe playback events."""
import math
import threading
import time
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


def episode_order(meta):
    try:
        season = int(meta.get('season') or 0)
        episode = float(meta['episode'])
        if season <= 0 or not math.isfinite(episode) or episode <= 0:
            return None
        return season, episode
    except (KeyError, TypeError, ValueError, OverflowError):
        return None


def next_episode(store, media):
    current = store.get(media)
    if not current:
        return None
    meta = current['metadata']
    order = episode_order(meta)
    if order is None or not media.startswith('episode:'):
        return None
    series = media.rsplit(':s', 1)[0]
    candidates = []
    for row in store.listing('episodes', limit=None):
        other = row['metadata']
        following = episode_order(other)
        if row['media'].rsplit(':s', 1)[0] != series or following is None or following <= order:
            continue
        # A provider route belongs to the same catalogue as the playing episode.
        # Never switch providers or guess links from episode numbers.
        if other.get('site') != meta.get('site'):
            continue
        route = urlsplit(other.get('route', ''))
        params = dict(parse_qsl(route.query))
        if route.scheme != 'plugin' or route.netloc != 'plugin.video.klarfilm':
            continue
        if params.get('isHoster') == 'true' or params.get('playMode') != 'play':
            continue
        candidates.append((following, other))
    return min(candidates, key=lambda pair: pair[0])[1] if candidates else None


def playback_route(meta):
    route = urlsplit(meta['route'])
    params = dict(parse_qsl(route.query))
    params.pop('manual', None)
    params['klarfilm_autonext'] = '1'
    params['playMode'] = 'play'
    return urlunsplit((route.scheme, route.netloc, route.path, urlencode(params), ''))


class Completion:
    """Callbacks only record events; the service loop performs Kodi/DB work."""
    def __init__(self, clock=time.monotonic):
        self.lock = threading.Lock()
        self.clock = clock
        self.active = None
        self.pending = None

    def started(self, media='', scope=''):
        with self.lock:
            self.pending = None
            self.active = (media, scope) if media and scope else None

    def ended(self):
        with self.lock:
            if self.active:
                self.pending = (self.active, self.clock() + 1)
                self.active = None

    def cancelled(self):
        self.started()

    def take(self):
        with self.lock:
            if not self.pending or self.clock() < self.pending[1]:
                return None
            result = self.pending[0]
            self.pending = None
            return result


def make_player(xbmc, completion):
    class EpisodePlayer(xbmc.Player):
        def onPlayBackStarted(self):
            completion.cancelled()

        def onAVStarted(self):
            try:
                tag = self.getVideoInfoTag()
                completion.started(tag.getUniqueID('klarfilm'),
                                   tag.getUniqueID('klarfilm_profile'))
            except Exception:
                completion.cancelled()

        def onPlayBackEnded(self):
            completion.ended()

        def onPlayBackStopped(self):
            completion.cancelled()

        def onPlayBackError(self):
            completion.cancelled()
    return EpisodePlayer()
