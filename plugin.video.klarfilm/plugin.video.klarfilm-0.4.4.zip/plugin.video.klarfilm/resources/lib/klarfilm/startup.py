"""GPL-3.0-or-later. Discover adapter defaults without executing their code."""
import ast
import json
import os
from pathlib import Path
import time
import xml.etree.ElementTree as ET
from http.cookiejar import LWPCookieJar


def stored_session(profile, domain):
    name = ''.join(c if (c.isascii() and c.isalnum()) or c in '-_' else '_' for c in domain)
    path = Path(profile) / 'cookies' / (name + '.txt')
    if not path.is_file():
        return 'Keine gespeicherten Webseiten-Cookies'
    jar = LWPCookieJar(str(path))
    try:
        jar.load(ignore_discard=True, ignore_expires=False)
    except (OSError, ValueError):
        return 'Gespeicherte Sitzung nicht lesbar'
    return 'Webseiten-Cookies vorhanden; keine Kontoanmeldung bestätigt' if list(jar) else 'Keine gültigen Webseiten-Cookies'


def inventory(root, setting, profile=None):
    root = Path(root)
    defaults = {el.get('id'): el.findtext('default', '') for el in ET.parse(root / 'resources/settings.xml').iter('setting')}
    result = []
    for path in sorted((root / 'sites').glob('*.py')):
        name, identifier, domain = path.stem, path.stem, ''
        for node in ast.parse(path.read_text(encoding='utf-8')).body:
            if not isinstance(node, ast.Assign):
                continue
            keys = {target.id for target in node.targets if isinstance(target, ast.Name)}
            if isinstance(node.value, ast.Constant):
                if 'SITE_NAME' in keys:
                    name = str(node.value.value)
                if 'SITE_IDENTIFIER' in keys:
                    identifier = str(node.value.value)
            if 'DOMAIN' in keys and isinstance(node.value, ast.Call) and len(node.value.args) >= 2:
                arg = node.value.args[1]
                if isinstance(arg, ast.Constant):
                    domain = str(arg.value)
        def value(key):
            return setting(key) or defaults.get(key, '')
        code = str(value('plugin_' + identifier + '_status'))
        enabled = value('plugin_' + identifier).lower() == 'true'
        if not enabled:
            state, description = 'disabled', 'Deaktiviert'
        elif code.isdigit() and 200 <= int(code) < 400:
            state, description = 'ready', 'Startseite erreichbar'
        elif not code or code.lower() == 'true':
            state, description = 'unknown', 'Noch nicht geprüft'
        else:
            state = 'issue'
            description = {'-1': 'Zeitüberschreitung', '-2': 'Zugriffsschutz', '-3': 'Verbindungsfehler',
                           '-4': 'Zugriffsschutz', '-5': 'Domain nicht erreichbar', '0': 'Unbekannter Fehler'}.get(code, 'HTTP ' + code)
        domain = value('plugin_' + identifier + '.domain') or domain
        result.append({'id': identifier, 'name': name, 'domain': domain,
                       'enabled': enabled, 'state': state, 'status': description,
                       'auth': 'Kein Konto-Anmeldeverfahren im Adapter hinterlegt',
                       'session': stored_session(profile, domain) if profile else 'Sitzung noch nicht geprüft'})
    return result


def episode_routes(root, setting):
    providers = {p['id']: p for p in inventory(root, setting)}
    routes = []
    for site, function, path in [('serienstream', 'showNeusteEpisoden', '/neue-episoden'),
                                 ('aniworld', 'showNewEpisodes', '/neue-episoden'),
                                 ('burningseries', 'showNewEpisodes', '/')]:
        provider = providers[site]
        if provider['enabled']:
            routes.append((provider['name'], {'site': site, 'function': function,
                                              'sUrl': 'https://' + provider['domain'].rstrip('/') + path}))
    return routes


def refresh_report():
    import xbmcaddon
    import xbmcvfs
    addon = xbmcaddon.Addon()
    from resources.lib.klarfilm.runtime import request_root
    profile = Path(request_root())
    profile.mkdir(parents=True, exist_ok=True)
    dependencies = {}
    for ident in ('script.module.resolveurl', 'inputstream.adaptive'):
        try:
            dependencies[ident] = xbmcaddon.Addon(ident).getAddonInfo('version')
        except Exception:
            dependencies[ident] = None
    report = {'prepared': time.time(), 'domain_check': addon.getSetting('klarfilm.last_domain_check'),
              'providers': inventory(addon.getAddonInfo('path'), addon.getSetting, profile), 'dependencies': dependencies}
    temporary = profile / 'startup.json.tmp'
    temporary.write_text(json.dumps(report, ensure_ascii=False), encoding='utf-8')
    os.replace(temporary, profile / 'startup.json')
    return report
