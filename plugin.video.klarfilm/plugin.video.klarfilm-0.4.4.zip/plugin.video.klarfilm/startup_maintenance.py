# -*- coding: utf-8 -*-
# Python 3

import os
import xbmc
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout

from resources.lib.config import cConfig
from resources.lib import tools
from resources.lib.logger import logger
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.handler.pluginHandler import cPluginHandler
from resources.lib import updateManager
from resources.lib.utils import translatePath
from resources.lib.cache import cCache
from resources.lib.tools import infoDialog


def delHtmlCache():
    # Cache nach X Tagen löschen (ohne Notification - läuft im Hintergrund beim Start)
    deltaDay = int(cConfig().getSetting('cacheDeltaDay', 1))
    if deltaDay == 0:  # 0 = aus
        return
    deltaTime = 60 * 60 * 24 * deltaDay
    currentTime = int(time.time())
    if currentTime >= int(cConfig().getSetting('lastdelhtml', 0)) + deltaTime:
        cRequestHandler('').clearCache(silent=True)  # ohne Notification (Auto-Cleanup)
        cConfig().setSetting('lastdelhtml', str(currentTime))


def _resolverUpdate():
    """Resolver Update im Hintergrund - gibt Status zurück für Notification.

    Laeuft bei jedem Start: den Schalter „Auto ResolveURL Update" gibt es seit dem
    01.11.2026 nicht mehr (Jack; er stand ab Werk an). Ob es etwas zu holen gibt,
    entscheidet updateManager am Commit von Gujals Master."""
    try:
        return updateManager.resolverUpdate()
    except Exception:
        import traceback
        logger.error('Resolver update error: %s' % traceback.format_exc())
        return False


def _lateResolverNotify(future):
    """Nachmeldung, wenn der Resolver-Check erst NACH dem 13s-Timeout fertig
    wird: gleiche Meldungslogik wie im Normalpfad in main() — Erfolg still,
    Fehlschlag mit Ton, None ('kein Update') bleibt stumm.
    Laeuft im Worker-Thread; infoDialog ist nur ein Notification-Toast und
    dort unkritisch. futures garantiert genau EINEN Aufruf pro Future."""
    try:
        status = future.result()
    except Exception:
        status = False
    if status == True: infoDialog(cConfig().getLocalizedString(30116), sound=False, icon='INFO', time=6000)
    if status == False: infoDialog(cConfig().getLocalizedString(30117), sound=True, icon='ERROR')


# Nachpruefung der Seiten, die beim Start-Check keine Antwort gaben (Status aus
# RETRY_STATUSES: Timeout, Verbindungsfehler, unbekannter Fehler). Seit dem 22.10.2026
# nimmt der Start-Check solche Seiten aus der globalen Suche — eine tote Seite kostete
# dort jeden Aufruf einen vollen requestTimeout (gemessen: 11,6 statt 2,5 s). Ein kurzer
# Aussetzer genau beim Kodi-Start (Netz noch nicht da, erster Kontakt hinter einem
# Schutzsystem langsam, ein VPN, das beim Boot erst noch verbindet) sieht aber genauso
# aus und klebte bis zum naechsten Start — deshalb werden NUR diese Seiten nach 2 Minuten
# noch einmal gefragt; antwortet die Seite, ist sie wieder in der Suche und das Timeout
# im Menue weg. EIN fester Versuch, keine Schleife (Jack 22.10.2026: eine Nachpruefung,
# 2 Minuten — nach einer Minute sind Netz, Handshake-Gedraenge und VPN sicher durch,
# jede Minute spaeter fehlt eine gesunde Seite laenger in der Suche; was danach noch
# nicht antwortet, steht mit [Timeout] im Menue und kommt ueber den manuellen Check).
# Das _main-Flag steht dabei laengst auf 'finished', das Hauptmenue wartet also nie auf
# die Nachpruefung; die Abrufe laufen wie beim Start in Daemon-Threads je Seite.
# xbmc.Monitor() als Basistyp (keine Unterklasse — Kodis neue SWIG-Python-Anbindung
# haelt Klassen von Unterklassen bis zum Skriptende fest); waitForAbort kehrt beim
# Beenden von Kodi sofort mit True zurueck.
RECHECK_DELAY = 120


def _recheckDomains():
    if xbmc.Monitor().waitForAbort(RECHECK_DELAY):
        return
    cPluginHandler().checkDomain(show_notify=False, retry=True)


def main():
    cCache().set(cConfig().getAddonInfo('id') + '_main', 'running')

    # Resolver Update und Domain Check parallel starten.
    # BEWUSST OHNE `with`: beim Verlassen eines with-Blocks ruft Python
    # shutdown(wait=True) auf und wartet auf den Thread — der Timeout unten
    # war dadurch wirkungslos und der Kodi-Start konnte trotzdem haengen.
    # Gleicher Fall wie in den Suchfunktionen von xstream.py.
    executor = ThreadPoolExecutor(max_workers=1)
    try:
        resolver_future = executor.submit(_resolverUpdate)

        # Domain Check läuft gleichzeitig im Main Thread
        # show_notify=False: silent beim Auto-Check beim Kodi-Start (User hat nicht aktiv angefragt).
        # Manueller Button-Click in xstream.py behaelt den Notify (Default-Parameter).
        cPluginHandler().checkDomain(show_notify=False)

        # Warte auf den Resolver. WICHTIG: ein abgelaufener Timeout ist KEIN
        # Fehler — das Update laeuft im Hintergrund weiter. Wuerde hier False
        # stehen, kaeme unten eine Fehlermeldung MIT TON, obwohl nichts
        # schiefgelaufen ist. 'skipped' haelt den Normalpfad unten still;
        # die Meldung holt _lateResolverNotify nach, sobald der Thread
        # fertig ist. Doppelmeldung ausgeschlossen: der Callback wird NUR
        # im Timeout-Fall angehaengt, und unten filtert 'skipped'.
        try:
            resolver_status = resolver_future.result(timeout=13)
        except FutureTimeout:
            resolver_status = 'skipped'
            # Feuert genau einmal — auch wenn der Thread just in diesem
            # Moment fertig geworden ist (dann sofort, sonst bei Abschluss).
            resolver_future.add_done_callback(_lateResolverNotify)
        except Exception:
            resolver_status = False
    finally:
        # Nicht auf den Thread warten — er laeuft zu Ende oder wird mit Kodi beendet.
        executor.shutdown(wait=False)

    # Html Cache aufraeumen BEVOR das Flag faellt: clearCache() leert auch
    # cRequestHandler.persistent_openers — dieser Zustand darf nicht auftreten,
    # waehrend der Nutzer schon durch die Seiten navigiert.
    delHtmlCache()

    # Domain Check und Cache-Aufraeumen muessen fertig sein, bevor das Hauptmenue startet
    # (xstream.py wartet auf dieses Flag).
    cConfig().setSetting('klarfilm.last_domain_check', str(time.time()))
    try:
        from resources.lib.klarfilm.startup import refresh_report
        refresh_report()
    except Exception:
        logger.warning('Klarfilm: Startbericht derzeit nicht verfügbar')
    cCache().set(cConfig().getAddonInfo('id') + '_main', 'finished')

    # Resolver Notification (nach Domain Check damit sich Notifications nicht überschneiden)
    # 'skipped' gibt es nur noch im Timeout-Fall (oben): die Meldung kommt dann verspaetet ueber
    # _lateResolverNotify. Einen abgeschalteten Check gibt es seit dem 01.11.2026 nicht mehr.
    # None ("kein Update verfuegbar") wird still abgehandelt, da uninteressant fuer User beim Auto-Check.
    # Bei manualResolverUpdate() bleibt der Notify fuer None erhalten (User hat aktiv geklickt).
    if resolver_status != 'skipped':
        if resolver_status == True: infoDialog(cConfig().getLocalizedString(30116), sound=False, icon='INFO', time=6000)
        if resolver_status == False: infoDialog(cConfig().getLocalizedString(30117), sound=True, icon='ERROR')

    # YouTube API Keys sicherstellen (Built-in Key für Video-Details/Alterscheck)
    # Klarfilm does not install bundled third-party credentials.

    # Zuletzt, weil der Service hierfuer zwei Minuten wach bleibt (Begruendung oben).
    _recheckDomains()


if __name__ == '__main__':
    main()
