# -*- coding: utf-8 -*-
"""Klarfilm Komplett - installs the bundled Kodi addons locally, no internet required."""
import os, zipfile, shutil, traceback, xml.etree.ElementTree as ET
import xbmc, xbmcaddon, xbmcgui, xbmcvfs

def notify(message):
    xbmc.log('[Klarfilm Komplett] ' + message, xbmc.LOGINFO)
    xbmcgui.Dialog().notification('Klarfilm Komplett', message, xbmcgui.NOTIFICATION_INFO, 9000)

def version_tuple(v):
    import re
    return tuple(int(x) for x in re.findall(r'\d+', v.split('+')[0]))

def install():
    addon=xbmcaddon.Addon()
    bundle=xbmcvfs.translatePath(addon.getAddonInfo('path'))
    home=xbmcvfs.translatePath('special://home/addons')
    os.makedirs(home,exist_ok=True)
    installed=[]
    for fn in sorted(os.listdir(os.path.join(bundle,'packages'))):
        if not fn.endswith('.zip'):continue
        archive=os.path.join(bundle,'packages',fn)
        with zipfile.ZipFile(archive) as z:
            bad=z.testzip()
            if bad:raise RuntimeError('ZIP damaged: '+fn)
            manifests=[n for n in z.namelist() if n.count('/')==1 and n.endswith('/addon.xml')]
            if len(manifests)!=1:raise RuntimeError('Invalid package: '+fn)
            addon_id=manifests[0].split('/')[0]
            manifest=ET.fromstring(z.read(manifests[0]))
            if manifest.get('id')!=addon_id:raise RuntimeError('Invalid addon id: '+fn)
            target=os.path.join(home,addon_id)
            if os.path.isfile(os.path.join(target,'addon.xml')):
                try:
                    current=ET.parse(os.path.join(target,'addon.xml')).getroot().get('version','0')
                    if version_tuple(current)>=version_tuple(manifest.get('version','0')):
                        continue
                except Exception:pass
            # Stage each package completely before replacing the existing directory.
            staging=os.path.join(home,'.klarfilm-staging-'+addon_id)
            if os.path.exists(staging):shutil.rmtree(staging)
            os.makedirs(staging)
            for item in z.infolist():
                parts=item.filename.replace('\\','/').split('/')
                if parts[0]!=addon_id or '..' in parts:raise RuntimeError('Unsafe ZIP path')
                relative='/'.join(parts[1:])
                if not relative:continue
                out=os.path.join(staging,relative)
                if item.is_dir():os.makedirs(out,exist_ok=True)
                else:
                    os.makedirs(os.path.dirname(out),exist_ok=True)
                    with z.open(item) as src,open(out,'wb') as dst:shutil.copyfileobj(src,dst)
            backup=target+'.klarfilm-backup'
            if os.path.exists(backup):shutil.rmtree(backup)
            if os.path.exists(target):os.rename(target,backup)
            try:os.rename(staging,target)
            except Exception:
                if os.path.exists(backup):os.rename(backup,target)
                raise
            if os.path.exists(backup):shutil.rmtree(backup)
            installed.append(addon_id)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')
    if installed:
        notify('Pakete installiert. Kodi bitte neu starten.')
    else:notify('Klarfilm und Abhaengigkeiten sind bereits vorhanden.')

try:install()
except Exception as exc:
    xbmc.log('[Klarfilm Komplett] Installation fehlgeschlagen: '+traceback.format_exc(),xbmc.LOGERROR)
    xbmcgui.Dialog().ok('Klarfilm Komplett','Installation fehlgeschlagen: '+str(exc))
