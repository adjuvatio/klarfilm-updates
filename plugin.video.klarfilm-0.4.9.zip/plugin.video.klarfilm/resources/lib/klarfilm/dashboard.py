"""GPL-3.0-or-later. Remote-friendly dashboard; home makes no network request."""
import sys
from urllib.parse import urlencode, parse_qs
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from resources.lib.klarfilm.runtime import state
from resources.lib.klarfilm.startup import inventory, episode_routes


def route(view, **params):
    return sys.argv[0] + '?' + urlencode(dict(params, function='klarfilm', view=view))


def add(label, path, folder=True, entry=None, description=''):
    item = xbmcgui.ListItem(label)
    from resources.lib.klarfilm.appearance import artwork
    item.setArt(artwork(xbmcaddon.Addon().getAddonInfo('path'), path))
    if description:
        item.getVideoInfoTag().setPlot(description)
    if entry:
        meta = entry['metadata']
        if meta.get('thumb'):
            item.setArt({'thumb': meta['thumb'], 'poster': meta['thumb']})
        tag = item.getVideoInfoTag()
        tag.setTitle(meta['title'])
        tag.setMediaType('episode' if meta.get('episode') else 'movie')
        tag.setPlaycount(int(entry['watched']))
        if entry['duration'] > 0 and not entry['watched']:
            tag.setResumePoint(entry['position'], entry['duration'])
        item.setProperty('IsPlayable', 'true')
        item.addContextMenuItems([('Aus Merkliste entfernen' if entry['watchlisted'] else 'Auf Merkliste setzen',
                                  'RunPlugin(' + route('toggle', media=entry['media']) + ')')])
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), path, item, folder)


def main(view='home'):
    from resources.lib.klarfilm.account_ui import VIEWS, manage
    if view in VIEWS:
        return manage(view)
    store = state()
    addon = xbmcaddon.Addon()
    args = {key: value[0] for key, value in parse_qs(sys.argv[2].lstrip('?')).items()}
    profile_name = store.remote_context.get('profile_name', 'Lokales Profil')
    xbmcplugin.setPluginCategory(int(sys.argv[1]), 'Klarfilm · ' + profile_name)
    navigation = []
    def emit(label, path, folder=True, entry=None, description=''):
        add(label, path, folder, entry, description)
        if folder:
            navigation.append((label, path))
    if view == 'check_updates':
        # Refresh the installed Klarfilm repository and open Kodi's add-on browser.
        # Kodi owns installation and permission prompts; never download or execute arbitrary ZIPs.
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmcgui.Dialog().notification('Klarfilm', 'Updatequelle wird geprüft – verfügbare Version in Kodi auswählen')
        xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://repository.klarfilm/)')
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
        return
    if view == 'toggle':
        added = store.toggle_watchlist(args.get('media', ''))
        xbmcgui.Dialog().notification('Klarfilm', 'Auf Merkliste gesetzt' if added else 'Aus Merkliste entfernt')
        xbmc.executebuiltin('Container.Refresh')
        return
    if view == 'home':
        film_progress = [r for r in store.listing('continue', limit=None)
                         if r['metadata'].get('kind', 'movie') != 'episode']
        items = [('Film weiterschauen', 'continue_movies', len(film_progress)),
                 ('Deine nächste Serienfolge', 'next', len(store.next_episodes())),
                 ('Merkliste', 'watchlist', len(store.listing('watchlist', limit=None))),
                 ('Entdecken', 'discover', None),
                 ('Mediathek', 'library', None), ('Suche', 'search_menu', None),
                 ('Anbieter', 'providers', None),
                 ('Aktualisierung prüfen', 'check_updates', None),
                 ('Profile & Einstellungen', 'account', None)]
        for label, key, count in items:
            emit('[B]' + label + '[/B]' + (' · ' + str(count) if count is not None else ''), route(key))
    elif view in ('series', 'series_seasons', 'series_episodes'):
        # Group by the same stable media identity used by the progress database.
        # Never merge unrelated series solely because their displayed names match.
        from collections import defaultdict
        groups = defaultdict(list)
        for row in store.listing('episodes', limit=None):
            media = row['media']
            if ':s' in media:
                groups[media.rsplit(':s', 1)[0]].append(row)
        if view == 'series':
            for key, episodes in sorted(groups.items(), key=lambda pair: (pair[1][0]['metadata'].get('showTitle') or pair[1][0]['metadata'].get('title') or '').casefold()):
                meta = episodes[0]['metadata']
                title = meta.get('showTitle') or meta.get('title') or 'Unbekannte Serie'
                seen = sum(bool(e['watched']) for e in episodes)
                emit(title + ' · {}/{} gesehen'.format(seen, len(episodes)),
                     route('series_seasons', series=key))
        elif view == 'series_seasons':
            episodes = groups.get(args.get('series', ''), [])
            seasons = defaultdict(list)
            for row in episodes:
                try:
                    season = int(row['metadata'].get('season') or 0)
                except (ValueError, TypeError):
                    season = 0
                seasons[season].append(row)
            for season, rows in sorted(seasons.items()):
                emit(('Staffel ' + str(season)) if season else 'Ohne Staffelzuordnung',
                     route('series_episodes', series=args.get('series', ''), season=season),
                     description='{} Folgen · {} gesehen'.format(len(rows), sum(bool(r['watched']) for r in rows)))
        else:
            try:
                season = int(args.get('season', '0'))
            except ValueError:
                season = 0
            episodes = []
            for row in groups.get(args.get('series', ''), []):
                meta = row['metadata']
                try:
                    row_season = int(meta.get('season') or 0)
                except (ValueError, TypeError):
                    row_season = 0
                if row_season == season:
                    episodes.append(row)
            def episode_order(row):
                try:
                    return float(row['metadata'].get('episode') or 0)
                except (ValueError, TypeError):
                    return 0
            for row in sorted(episodes, key=episode_order):
                meta = row['metadata']
                emit('Folge {} · {}'.format(meta.get('episode') or '?', meta['title']),
                     meta['route'], False, row)
            xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    elif view in ('continue', 'continue_movies', 'next', 'watchlist', 'movies', 'episodes', 'history', 'discovered', 'search_local'):
        rows = store.next_episodes() if view == 'next' else store.listing(view, limit=None if view == 'search_local' else 200)
        if view == 'continue_movies':
            rows = [r for r in store.listing('continue', limit=None)
                    if r['metadata'].get('kind', 'movie') != 'episode'][:200]
        if view == 'search_local':
            query = xbmcgui.Dialog().input('Titel in meiner Mediathek suchen').casefold().strip()
            rows = [row for row in rows if query and query in (row['metadata'].get('title', '') + ' ' + row['metadata'].get('showTitle', '')).casefold()][:200]
        for row in rows:
            meta = row['metadata']
            label = meta['title']
            if meta.get('episode'):
                label = (meta.get('showTitle') or label) + ' · S{}E{} · {}'.format(meta.get('season') or 0, meta['episode'], meta['title'])
            if row['duration'] > 0 and not row['watched']:
                label += ' · {} %'.format(int(100 * row['position'] / row['duration']))
            emit(label, meta['route'], False, row)
        xbmcplugin.setContent(int(sys.argv[1]), 'videos')
        if not rows:
            xbmcgui.Dialog().notification('Klarfilm', 'Noch keine passenden Titel – Anbieter öffnen oder Suche nutzen')
    elif view == 'new_episodes':
        for label, params in episode_routes(addon.getAddonInfo('path'), addon.getSetting):
            emit(label, sys.argv[0] + '?' + urlencode(params))
    elif view == 'discover':
        emit('Neue Serienfolgen nach Anbieter', route('new_episodes'))
        emit('Filme: Kino, neu für daheim und Streaming-Plattformen', sys.argv[0] + '?' + urlencode({'site': 'tmdb_browser', 'function': 'showMoviesMenu'}),
            description='Metadaten sind keine Zusage einer abspielbaren Quelle.')
        emit('Serien entdecken – TMDb', sys.argv[0] + '?' + urlencode({'site': 'tmdb_browser', 'function': 'showTVShowsMenu'}))
        emit('Zuletzt entdeckte Titel', route('discovered'))
        emit('Alle Anbieter und Filmkataloge', route('upstream'))
    elif view == 'library':
        for label, key in [('Meine Filme', 'movies'), ('Meine Serien', 'series'), ('Zuletzt gesehen', 'history')]:
            emit(label, route(key))
    elif view == 'search_menu':
        emit('Anbieterübergreifend suchen', sys.argv[0] + '?' + urlencode({'site': 'globalSearch', 'function': 'globalSearch'}))
        emit('In meiner Mediathek suchen', route('search_local'))
    elif view == 'providers':
        from resources.lib.klarfilm.runtime import request_root
        providers = inventory(addon.getAddonInfo('path'), addon.getSetting, request_root())
        for provider in sorted(providers, key=lambda p: ({'ready': 0, 'unknown': 1, 'issue': 2, 'disabled': 3}[p['state']], p['name'])):
            label = provider['name'] + ' · ' + provider['status']
            detail = provider['domain'] + '\n' + provider['auth'] + '\n' + provider['session'] + '\nLetztes gespeichertes Prüfergebnis; bestätigt noch keine Wiedergabe.'
            path = sys.argv[0] + '?' + urlencode({'site': provider['id'], 'function': 'load'}) if provider['enabled'] else route('settings')
            emit(label, path, description=detail)
        emit('Domains jetzt prüfen', sys.argv[0] + '?' + urlencode({'function': 'domainCheck'}))
        emit('Synchronisierung und Konflikte', route('status'))
        emit('VPN und Datenschutz', route('privacy'))
        emit('Vollständige Anbieter-/Suchoberfläche', route('upstream'))
    elif view == 'status':
        counts = store.counts()
        message = addon.getSetting('klarfilm.sync_status') or 'Noch nicht verbunden'
        xbmcgui.Dialog().ok('Synchronisierung', message + '\nAusstehend: {} · Konflikte: {}\n'
            'Verlauf und Merkliste bleiben bei Ausfällen lokal gespeichert.'.format(
                counts.get('pending', 0) + counts.get('sending', 0), counts.get('conflict', 0)))
        if counts.get('conflict') and xbmcgui.Dialog().yesno('Fortschrittskonflikte',
                'Für die betroffenen Titel den Serverstand übernehmen? Lokale Konfliktstände werden verworfen.'):
            store.discard_conflicts()
    elif view == 'settings':
        addon.openSettings()
    elif view == 'privacy':
        xbmcgui.Dialog().ok('VPN und Datenschutz',
            'Kein Tunnelstatus bestätigt. Eigenen WireGuard-Ausgang und Netzwerksperre gemäß Anleitung einrichten.\n'
            'Das Add-on selbst verbirgt keine IP. Zugangsdaten werden nicht aus fremden Konten beschafft.')
    # Only immutable, local menu routes may be cached by Kodi.
    static_views = ('library', 'search_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=view in static_views)
    if view == 'home':
        addon.setSetting('klarfilm.service_enabled', 'true')

    if navigation and view in ('home', 'library', 'discover', 'search_menu', 'providers', 'new_episodes'):
        from resources.lib.klarfilm.navigation import show_navigation
        try:
            selected = show_navigation(navigation, addon, profile_name, view)
            if selected:
                xbmc.executebuiltin('Container.Update(' + selected + ')')
            else:
                # One back action closes the modal; Kodi retains its own navigation stack.
                pass
        except Exception:
            xbmc.log('Klarfilm: Kachelansicht konnte nicht geöffnet werden', xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Klarfilm', 'Kachelansicht nicht verfügbar – Listenansicht geöffnet')
