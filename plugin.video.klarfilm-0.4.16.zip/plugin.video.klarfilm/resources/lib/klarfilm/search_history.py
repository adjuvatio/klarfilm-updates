"""Persistent local Klarfilm search history."""
import json
import xbmcaddon

def recent():
    try:
        data = json.loads(xbmcaddon.Addon().getSetting('klarfilm.search_history') or '[]')
        return [x for x in data if isinstance(x, str) and x.strip()][:20]
    except (TypeError, ValueError):
        return []

def remember(query):
    query = str(query or '').strip()[:160]
    if query:
        xbmcaddon.Addon().setSetting('klarfilm.search_history', json.dumps(
            [query] + [x for x in recent() if x.casefold() != query.casefold()][:19], ensure_ascii=False))
